import pygame
import sys

pygame.init()
# ==================================================
# CONFIGURAÇÕES
# ==================================================

WIDTH = 1280
HEIGHT = 720

screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("DDCC - Doki Doki Conguitos Club")

clock = pygame.time.Clock()

FPS = 60

# ==================================================
# FONTES
# ==================================================

font_name = pygame.font.SysFont("arial", 32, bold=True)
font_text = pygame.font.SysFont("arial", 26)
font_choice = pygame.font.SysFont("arial", 24)

# ==================================================
# CORES
# ==================================================

WHITE = (255,255,255)
BLACK = (0,0,0)
GRAY = (235,235,235)
DARKGRAY = (120,120,120)

# ==================================================
# IMAGENS
# ==================================================

backgrounds = {

    "fora": pygame.transform.scale(
        pygame.image.load("backgroundFora.jpg").convert(),
        (WIDTH,HEIGHT)
    ),

    "loja": pygame.transform.scale(
        pygame.image.load("backgroundLoja.png").convert(),
        (WIDTH,HEIGHT)
    )

}

characters = {

    "calstone": pygame.transform.scale(
        pygame.image.load("calstone.png").convert_alpha(),
        (350,350)
    ),

    "itadori": pygame.transform.scale(
        pygame.image.load("itadori.png").convert_alpha(),
        (350,350)
    ),

    "logo": pygame.transform.scale(
        pygame.image.load("logo.png").convert_alpha(),
        (350,350)
    ),

    "conguitos": pygame.transform.scale(
        pygame.image.load("conguitos.png").convert_alpha(),
        (350,350)
    )

}

# Caixa de diálogo personalizada
dialog_box = pygame.image.load("caixa de texto.png").convert_alpha()

# Redimensiona para o tamanho da caixa original
dialog_box = pygame.transform.scale(
    dialog_box,
    (1220, 220)
)

logo = pygame.transform.scale(
    pygame.image.load("logo.png").convert_alpha(),
    (500,500)
)

# ==================================================
# ANIMAÇÃO DE ENTRADA DO PERSONAGEM
# ==================================================

character_x = 870
character_y = 120

character_alpha = 255
character_scale = 1.0

fade_speed = 30
scale_speed = 0.04

animating = False

current_character = None

character_visible = False

def start_character_animation():

    global character_alpha
    global character_scale
    global animating

    character_alpha = 0
    character_scale = 0.70

    animating = True


def update_character_animation():

    global character_alpha
    global character_scale
    global animating

    if animating:

        if character_alpha < 255:
            character_alpha += fade_speed

        if character_scale < 1:
            character_scale += scale_speed

        if character_alpha > 255:
            character_alpha = 255

        if character_scale > 1:
            character_scale = 1

        if character_alpha >= 255 and character_scale >= 1:
            animating = False

# ==================================================
# INTRO
# ==================================================

def intro():

    alpha = 0

    # Fade In

    while alpha < 255:

        for e in pygame.event.get():

            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        screen.fill(BLACK)

        img = logo.copy()
        img.set_alpha(alpha)

        rect = img.get_rect(center=(WIDTH//2,HEIGHT//2))

        screen.blit(img,rect)

        pygame.display.flip()

        alpha += 5

        clock.tick(FPS)

    # Espera

    start = pygame.time.get_ticks()

    while pygame.time.get_ticks()-start < 1800:

        for e in pygame.event.get():

            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        screen.fill(BLACK)

        rect = logo.get_rect(center=(WIDTH//2,HEIGHT//2))

        screen.blit(logo,rect)

        pygame.display.flip()

        clock.tick(FPS)

    # Fade Out

    alpha = 255

    while alpha > 0:

        for e in pygame.event.get():

            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

        screen.fill(BLACK)

        img = logo.copy()
        img.set_alpha(alpha)

        rect = img.get_rect(center=(WIDTH//2,HEIGHT//2))

        screen.blit(img,rect)

        pygame.display.flip()

        alpha -= 5

        clock.tick(FPS)

# ==================================================
# HISTÓRIA
# ==================================================

story = {

    "inicio":{

        "type":"dialog",

        "background":"fora",

        "character":"calstone",

        "name":"Calstone",

        "text":"Hoje parece um ótimo dia para sair.",

        "next":"fala2"

    },

    "fala2":{

        "type":"dialog",

        "background":"fora",

        "character":"itadori",

        "name":"Itadori",

        "text":"Ouvi dizer que abriram uma loja nova.",

        "next":"fala3"

    },

    "fala3":{

        "type":"dialog",

        "background":"loja",

        "character":"calstone",

        "name":"Calstone",

        "text":"Vamos comprar um boneco do Conguitos?",

        "next":"escolha1"

    },

    "escolha1":{

        "type":"choice",

        "background":"loja",

        "character":"conguitos",

        "question":"O que você faz?",

        "choices":[

            ("Vamos comprar.","rota1"),

            ("Melhor não.","rota2"),

            ("Quanto custa?","rota3")

        ]

    },

    "rota1":{

        "type":"dialog",

        "background":"loja",

        "character":"itadori",

        "name":"Itadori",

        "text":"Boa ideia!",
        "next":"fim"

    },

    "rota2":{

        "type":"dialog",

        "background":"loja",

        "character":"calstone",

        "name":"Calstone",

        "text":"Tudo bem, talvez outro dia.",

        "next":"fim"

    },

    "rota3":{

        "type":"dialog",

        "background":"loja",

        "character":"logo",

        "name":"Vendedor",

        "text":"Custa R$79,90.",

        "next":"fim"

    },

    "fim":{

        "type":"dialog",

        "background":"fora",

        "character":"calstone",

        "name":"Narrador",

        "text":"Fim da demonstração.",

        "next":None

    }

}

current_scene = "inicio"

# ==================================================
# FUNÇÕES DO JOGO
# ==================================================

def draw_text(text, font, color, x, y, max_width):

    palavras = text.split(" ")
    linhas = []
    linha = ""

    for palavra in palavras:

        teste = linha + palavra + " "

        if font.size(teste)[0] <= max_width:
            linha = teste

        else:
            linhas.append(linha)
            linha = palavra + " "

    linhas.append(linha)

    for i, linha in enumerate(linhas):

        img = font.render(linha, True, color)
        screen.blit(img, (x, y + i * 35))


def change_scene(nova):

    global current_scene
    global current_character
    global character_visible

    cena_atual = story[current_scene]
    nova_cena = story[nova]

    personagem_atual = cena_atual.get("character")
    novo_personagem = nova_cena.get("character")

    current_scene = nova

    # Caso não exista personagem
    if novo_personagem is None:
        character_visible = False
        current_character = None
        return

    # Personagem entrando pela primeira vez
    if not character_visible:
        current_character = novo_personagem
        character_visible = True
        start_character_animation()
        return

    # Personagem mudou
    if novo_personagem != current_character:
        current_character = novo_personagem
        start_character_animation()


# ==================================================
# INICIA INTRO
# ==================================================

intro()


# ==================================================
# LOOP PRINCIPAL
# ==================================================

running = True

while running:

    scene = story[current_scene]

    if current_character is None:
        current_character = scene["character"]
        character_visible = True
        start_character_animation()

    # --------------------------
    # EVENTOS
    # --------------------------

    for event in pygame.event.get():

        if event.type == pygame.QUIT:
            running = False

        if event.type == pygame.KEYDOWN:

            if scene["type"] == "dialog":

                if event.key == pygame.K_SPACE:

                    if scene["next"]:
                        change_scene(scene["next"])

            elif scene["type"] == "choice":

                if event.key == pygame.K_1:
                    change_scene(scene["choices"][0][1])

                elif event.key == pygame.K_2 and len(scene["choices"]) >= 2:
                    change_scene(scene["choices"][1][1])

                elif event.key == pygame.K_3 and len(scene["choices"]) >= 3:
                    change_scene(scene["choices"][2][1])

                elif event.key == pygame.K_4 and len(scene["choices"]) >= 4:
                    change_scene(scene["choices"][3][1])

        if event.type == pygame.MOUSEBUTTONDOWN:

            mouse = pygame.mouse.get_pos()

            if scene["type"] == "dialog":

                if scene["next"]:
                    change_scene(scene["next"])

            elif scene["type"] == "choice":

                for i, escolha in enumerate(scene["choices"]):

                    rect = pygame.Rect(
                        70,
                        470 + i * 60,
                        500,
                        45
                    )

                    if rect.collidepoint(mouse):
                        change_scene(escolha[1])

    # --------------------------
    # ATUALIZAÇÃO
    # --------------------------

    update_character_animation()

    # --------------------------
    # DESENHO
    # --------------------------

    fundo = backgrounds[scene["background"]]
    screen.blit(fundo, (0, 0))

    # PERSONAGEM

    personagem = characters[scene["character"]]

    largura_original = personagem.get_width()
    altura_original = personagem.get_height()

    nova_largura = int(largura_original * character_scale)
    nova_altura = int(altura_original * character_scale)

    sprite = pygame.transform.smoothscale(
        personagem,
        (nova_largura, nova_altura)
    )

    sprite.set_alpha(int(character_alpha))

    x = character_x + (largura_original - nova_largura) // 2
    y = character_y + (altura_original - nova_altura)

    screen.blit(sprite, (x, y))

    # CAIXA DE DIÁLOGO

    screen.blit(dialog_box, (30, 470))

    # DIÁLOGO

    if scene["type"] == "dialog":

        nome = font_name.render(
            scene["name"],
            True,
            BLACK
        )

        screen.blit(nome, (60, 500))

        draw_text(
            scene["text"],
            font_text,
            BLACK,
            60,
            550,
            1000
        )

        info = font_choice.render(
            "ESPAÇO ou clique para continuar",
            True,
            DARKGRAY
        )

        screen.blit(info, (60, 650))

    # ESCOLHAS

    elif scene["type"] == "choice":

        pergunta = font_name.render(
            scene["question"],
            True,
            BLACK
        )

        screen.blit(pergunta, (60, 500))

        for i, escolha in enumerate(scene["choices"]):

            y = 550 + i * 40

            texto = font_choice.render(
                f"{i+1}. {escolha[0]}",
                True,
                BLACK
            )

            screen.blit(texto, (80, y))

    pygame.display.flip()
    clock.tick(FPS)

pygame.quit()
sys.exit()