import pygame
import sys

from config import (
    LARGURA,
    ALTURA,
    FPS,
    TITULO,
    VIDA_MAXIMA
)

from recursos import (
    carregar_mapa,
    carregar_personagem,
    carregar_coracao
)

from jogador import Jogador

from coracao import Coracao

from interface import Interface


# ==========================================
# INICIALIZAR PYGAME
# ==========================================

pygame.init()


# ==========================================
# JANELA
# ==========================================

tela = pygame.display.set_mode(
    (
        LARGURA,
        ALTURA
    )
)

pygame.display.set_caption(
    TITULO
)


# ==========================================
# CLOCK
# ==========================================

clock = pygame.time.Clock()


# ==========================================
# CARREGAR RECURSOS
# ==========================================

mapa = carregar_mapa()

(
    baixo,
    cima,
    esquerda,
    direita
) = carregar_personagem()

coracao_sprites = (
    carregar_coracao()
)


# ==========================================
# CRIAR JOGADOR
# ==========================================

jogador = Jogador(
    baixo,
    cima,
    esquerda,
    direita,
    mapa,
    LARGURA,
    ALTURA
)


# ==========================================
# CRIAR CORAÇÃO
# ==========================================

coracao = Coracao(
    coracao_sprites,
    LARGURA,
    ALTURA
)


# ==========================================
# CRIAR INTERFACE
# ==========================================

interface = Interface(
    VIDA_MAXIMA
)


# ==========================================
# LOOP PRINCIPAL
# ==========================================

rodando = True


while rodando:

    # ======================================
    # EVENTOS
    # ======================================

    for evento in pygame.event.get():

        if evento.type == pygame.QUIT:

            rodando = False

        # ==================================
        # TECLAS
        # ==================================

        if evento.type == pygame.KEYDOWN:

            # Espaço ativa/desativa coração

            if evento.key == pygame.K_SPACE:

                coracao.ativo = (
                    not coracao.ativo
                )

    # ======================================
    # ATUALIZAR JOGADOR
    # ======================================

    jogador.atualizar()


    # ======================================
    # ATUALIZAR CORAÇÃO
    # ======================================

    coracao.atualizar()


    # ======================================
    # DESENHAR FUNDO
    # ======================================

    tela.fill(
        (0, 0, 0)
    )

    tela.blit(
        mapa,
        (0, 0)
    )


    # ======================================
    # DESENHAR JOGADOR
    # ======================================

    jogador.desenhar(
        tela
    )


    # ======================================
    # DESENHAR CORAÇÃO
    # ======================================

    coracao.desenhar(
        tela,
        jogador
    )


    # ======================================
    # DESENHAR INTERFACE
    # ======================================

    interface.desenhar_vida(
        tela
    )


    # ======================================
    # ATUALIZAR TELA
    # ======================================

    pygame.display.flip()


    # ======================================
    # FPS
    # ======================================

    clock.tick(FPS)


# ==========================================
# ENCERRAR
# ==========================================

pygame.quit()

sys.exit()