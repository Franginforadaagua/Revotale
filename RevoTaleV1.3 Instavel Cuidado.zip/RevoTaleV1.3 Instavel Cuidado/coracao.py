import pygame


class Coracao:

    def __init__(
        self,
        sprites,
        largura_tela,
        altura_tela
    ):

        self.sprites = sprites

        self.ativo = False

        # ==========================================
        # ANIMAÇÃO
        # ==========================================

        self.indice = 0

        self.contador = 0

        self.velocidade = 8

        # ==========================================
        # ESCURECIMENTO
        # ==========================================

        self.escurecimento = pygame.Surface(
            (
                largura_tela,
                altura_tela
            )
        )

        self.escurecimento.fill(
            (0, 0, 0)
        )

        self.alpha = 0

    # ==========================================
    # ATUALIZAR
    # ==========================================

    def atualizar(self):

        # ======================================
        # ANIMAÇÃO
        # ======================================

        self.contador += 1

        if self.contador >= self.velocidade:

            self.contador = 0

            self.indice += 1

            if self.indice >= len(
                self.sprites
            ):

                self.indice = 0

        # ======================================
        # ESCURECIMENTO
        # ======================================

        if self.ativo:

            if self.alpha < 150:

                self.alpha += 5

        else:

            if self.alpha > 0:

                self.alpha -= 5

        self.escurecimento.set_alpha(
            self.alpha
        )

    # ==========================================
    # DESENHAR
    # ==========================================

    def desenhar(
        self,
        tela,
        jogador
    ):

        if self.alpha <= 0:
            return

        # ======================================
        # ESCURECIMENTO
        # ======================================

        tela.blit(
            self.escurecimento,
            (0, 0)
        )

        # ======================================
        # SPRITE DO CORAÇÃO
        # ======================================

        sprite_jogador = (
            jogador.pegar_sprite()
        )

        sprite_coracao = (
            self.sprites[
                self.indice
            ].copy()
        )

        # ======================================
        # CENTRALIZAR CORAÇÃO
        # ======================================

        coracao_x = (
            jogador.x
            +
            (
                sprite_jogador.get_width()
                -
                sprite_coracao.get_width()
            )
            // 2
        )

        coracao_y = (
            jogador.y
            +
            (
                sprite_jogador.get_height()
                -
                sprite_coracao.get_height()
            )
            // 2
        )

        # ======================================
        # TRANSPARÊNCIA
        # ======================================

        sprite_coracao.set_alpha(
            self.alpha * 2
        )

        tela.blit(
            sprite_coracao,
            (
                coracao_x,
                coracao_y
            )
        )