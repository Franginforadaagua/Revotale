import pygame
import math

from config import VELOCIDADE
from colisao import pode_andar


class Jogador:

    def __init__(
        self,
        baixo,
        cima,
        esquerda,
        direita,
        mapa,
        largura_tela,
        altura_tela
    ):

        # ==========================================
        # SPRITES
        # ==========================================

        self.baixo = baixo
        self.cima = cima
        self.esquerda = esquerda
        self.direita = direita

        self.mapa = mapa

        self.largura_tela = largura_tela
        self.altura_tela = altura_tela

        # ==========================================
        # CONFIGURAÇÕES
        # ==========================================

        self.velocidade = VELOCIDADE

        self.direcao = "baixo"

        self.direcao_anterior = "baixo"

        self.olhando_esquerda = False

        # ==========================================
        # ANIMAÇÃO
        # ==========================================

        self.sequencia_baixo = [
            0,
            1,
            2,
            3
        ]

        self.sequencia_cima = [
            0,
            1,
            2,
            3
        ]

        self.sequencia_lado = [
            0,
            1,
            2,
            3,
            4
        ]

        self.indice_animacao = 0

        self.frame = 0

        self.contador_animacao = 0

        self.velocidade_animacao = 8

        # ==========================================
        # POSIÇÃO INICIAL
        # ==========================================

        sprite_inicial = self.baixo[0]

        self.x = (
            largura_tela
            - sprite_inicial.get_width()
        ) // 2

        self.y = (
            altura_tela
            - sprite_inicial.get_height()
        ) // 2

    # ==========================================
    # PEGAR SPRITE
    # ==========================================

    def pegar_sprite(self):

        if self.direcao == "baixo":

            if self.frame >= len(self.baixo):
                return self.baixo[0]

            return self.baixo[self.frame]

        elif self.direcao == "cima":

            if self.frame >= len(self.cima):
                return self.cima[0]

            return self.cima[self.frame]

        elif self.direcao == "esquerda":

            if self.frame >= len(self.esquerda):
                return self.esquerda[0]

            return self.esquerda[self.frame]

        elif self.direcao == "direita":

            if self.frame >= len(self.direita):
                return self.direita[0]

            return self.direita[self.frame]

        return self.baixo[0]

    # ==========================================
    # MOVIMENTO
    # ==========================================

    def atualizar_movimento(self):

        teclas = pygame.key.get_pressed()

        movendo = False

        novo_x = self.x
        novo_y = self.y

        # ======================================
        # DIREÇÃO
        # ======================================

        direcao_x = 0
        direcao_y = 0

        # Horizontal

        if (
            teclas[pygame.K_a]
            or
            teclas[pygame.K_LEFT]
        ):
            direcao_x -= 1

        if (
            teclas[pygame.K_d]
            or
            teclas[pygame.K_RIGHT]
        ):
            direcao_x += 1

        # Vertical

        if (
            teclas[pygame.K_w]
            or
            teclas[pygame.K_UP]
        ):
            direcao_y -= 1

        if (
            teclas[pygame.K_s]
            or
            teclas[pygame.K_DOWN]
        ):
            direcao_y += 1

        # ======================================
        # NORMALIZAR DIAGONAL
        # ======================================

        if (
            direcao_x != 0
            and
            direcao_y != 0
        ):

            fator = (
                self.velocidade
                /
                math.sqrt(2)
            )

            movimento_x = (
                direcao_x * fator
            )

            movimento_y = (
                direcao_y * fator
            )

        else:

            movimento_x = (
                direcao_x
                * self.velocidade
            )

            movimento_y = (
                direcao_y
                * self.velocidade
            )

        # ======================================
        # APLICAR MOVIMENTO
        # ======================================

        novo_x += movimento_x
        novo_y += movimento_y

        # ======================================
        # DEFINIR DIREÇÃO
        # ======================================

        if direcao_x < 0:

            self.direcao = "esquerda"

            self.olhando_esquerda = True

            movendo = True

        elif direcao_x > 0:

            self.direcao = "direita"

            self.olhando_esquerda = False

            movendo = True

        elif direcao_y < 0:

            self.direcao = "cima"

            movendo = True

        elif direcao_y > 0:

            self.direcao = "baixo"

            movendo = True

        # ======================================
        # COLISÃO
        # ======================================

        sprite = self.pegar_sprite()

        if pode_andar(
            novo_x,
            novo_y,
            sprite,
            self.mapa
        ):

            self.x = novo_x
            self.y = novo_y

        # ======================================
        # MUDOU DE DIREÇÃO
        # ======================================

        if (
            self.direcao
            !=
            self.direcao_anterior
        ):

            self.indice_animacao = 0

            self.frame = 0

            self.contador_animacao = 0

            self.direcao_anterior = (
                self.direcao
            )

        # ======================================
        # ANIMAÇÃO
        # ======================================

        self.atualizar_animacao(
            movendo
        )

    # ==========================================
    # ANIMAÇÃO
    # ==========================================

    def atualizar_animacao(
        self,
        movendo
    ):

        if movendo:

            self.contador_animacao += 1

            if (
                self.contador_animacao
                >=
                self.velocidade_animacao
            ):

                self.contador_animacao = 0

                if self.direcao == "baixo":

                    sequencia = (
                        self.sequencia_baixo
                    )

                elif self.direcao == "cima":

                    sequencia = (
                        self.sequencia_cima
                    )

                else:

                    sequencia = (
                        self.sequencia_lado
                    )

                self.indice_animacao += 1

                if (
                    self.indice_animacao
                    >=
                    len(sequencia)
                ):

                    self.indice_animacao = 0

                self.frame = (
                    sequencia[
                        self.indice_animacao
                    ]
                )

        else:

            # ==================================
            # IDLE
            # ==================================

            self.frame = 0

            self.indice_animacao = 0

            self.contador_animacao = 0

    # ==========================================
    # ATUALIZAR
    # ==========================================

    def atualizar(self):

        self.atualizar_movimento()

    # ==========================================
    # DESENHAR
    # ==========================================

    def desenhar(self, tela):

        sprite = self.pegar_sprite()

        tela.blit(
            sprite,
            (
                self.x,
                self.y
            )
        )