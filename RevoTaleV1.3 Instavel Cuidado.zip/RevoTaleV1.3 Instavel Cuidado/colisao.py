import pygame

from config import LARGURA, ALTURA


# ==========================================
# VERIFICAR SE UMA COR É ROXA
# ==========================================

def eh_roxo(cor):

    r = cor[0]
    g = cor[1]
    b = cor[2]

    # Muito vermelho
    # Pouco verde
    # Muito azul

    if r > 80 and b > 80 and g < 100:
        return True

    return False


# ==========================================
# COLISÃO
# ==========================================

def pode_andar(
    novo_x,
    novo_y,
    sprite,
    mapa
):

    largura = sprite.get_width()
    altura = sprite.get_height()

    # ======================================
    # CAIXA DE COLISÃO DOS PÉS
    # ======================================

    largura_colisao = int(
        largura * 0.55
    )

    altura_colisao = int(
        altura * 0.20
    )

    # Centraliza horizontalmente

    colisao_x = (
        novo_x
        + (largura - largura_colisao) // 2
    )

    # Coloca na parte inferior

    colisao_y = (
        novo_y
        + altura
        - altura_colisao
        - 5
    )

    hitbox = pygame.Rect(
        colisao_x,
        colisao_y,
        largura_colisao,
        altura_colisao
    )

    # ======================================
    # PONTOS DA HITBOX
    # ======================================

    pontos = [

        # Pé esquerdo
        (
            hitbox.left,
            hitbox.bottom - 1
        ),

        # Pé direito
        (
            hitbox.right - 1,
            hitbox.bottom - 1
        ),

        # Centro dos pés
        (
            hitbox.centerx,
            hitbox.bottom - 1
        ),

        # Parte de cima
        (
            hitbox.left,
            hitbox.top
        ),

        (
            hitbox.right - 1,
            hitbox.top
        )
    ]

    # ======================================
    # VERIFICAR COLISÃO
    # ======================================

    for px, py in pontos:

        if (
            0 <= px < LARGURA
            and
            0 <= py < ALTURA
        ):

            cor = mapa.get_at(
                (
                    int(px),
                    int(py)
                )
            )

            # Verifica parede roxa

            if (
                cor[3] > 0
                and
                eh_roxo(cor)
            ):
                return False

    return True