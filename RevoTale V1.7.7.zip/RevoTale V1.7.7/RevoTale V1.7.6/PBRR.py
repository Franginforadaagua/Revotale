import math
import random

import pygame
from config import TAMANHO_TILE
from colisao import eh_parede, pode_andar


# =========================================================
# CONFIGURAÇÕES
# =========================================================

VELOCIDADE = 6
VELOCIDADE_IA = 2
VELOCIDADE_ANIMACAO = 8
LARGURA_HITBOX = 24
ALTURA_HITBOX = 16
DESLOCAMENTO_HITBOX_X = 4
TEMPO_MOVIMENTO_ALEATORIO = 60
TEMPO_PERSEGUINDO = 120
INTERVALO_ATAQUE = 90
ALCANCE_ATAQUE = 320
VELOCIDADE_ATAQUE = 7


# =========================================================
# CLASSE PBRR (PERSONAGEM CONTROLÁVEL)
# =========================================================

class PBRR:
    """
    Classe para controlar um personagem com movimento livre,
    animações em 4 direções e colisão com o mapa.
    """

    def __init__(
        self,
        frente,
        costas,
        esquerda,
        direita,
        x,
        y
    ):
        """
        Inicializa o personagem PBRR.

        Args:
            frente: Lista de sprites para andar para frente
            costas: Lista de sprites para andar para trás
            esquerda: Lista de sprites para andar para esquerda
            direita: Lista de sprites para andar para direita
            x: Posição inicial X
            y: Posição inicial Y
        """

        # =================================================
        # SPRITES
        # =================================================

        self.frente = frente
        self.costas = costas
        self.esquerda = esquerda
        self.direita = direita

        # =================================================
        # POSIÇÃO
        # =================================================

        self.x = x
        self.y = y

        # =================================================
        # DIREÇÃO
        # =================================================

        self.direcao = "frente"
        self.direcao_anterior = "frente"

        # =================================================
        # MOVIMENTO
        # =================================================

        self.velocidade = VELOCIDADE
        self.velocidade_ia = VELOCIDADE_IA

        self.movimento_x = 0
        self.movimento_y = 0

        # =================================================
        # ANIMAÇÃO
        # =================================================

        self.frame = 0
        self.contador_animacao = 0
        self.velocidade_animacao = VELOCIDADE_ANIMACAO

        # =================================================
        # ESTADO
        # =================================================

        self.esta_se_movendo = False

        # Estado da inteligencia artificial
        self.modo_ia = "aleatorio"
        self.tempo_ia = TEMPO_MOVIMENTO_ALEATORIO
        self.direcao_aleatoria = self._sortear_direcao()

        self.sprite_ataque = pygame.image.load(
            "assets/ataques/ataque1.png"
        ).convert_alpha()
        self.ataques = []
        self.tempo_ataque = 0

    # =====================================================
    # PEGAR SPRITE ATUAL
    # =====================================================

    def pegar_sprite(self):
        """
        Retorna o sprite atual baseado na direção e frame.

        Returns:
            pygame.Surface: Imagem do sprite
        """

        # Escolher lista de sprites baseado na direção
        if self.direcao == "costas":
            sprites = self.costas
        elif self.direcao == "frente":
            sprites = self.frente
        elif self.direcao == "esquerda":
            sprites = self.esquerda
        elif self.direcao == "direita":
            sprites = self.direita
        else:
            sprites = self.frente

        # Validar índice do frame
        if self.frame >= len(sprites):
            self.frame = 0
            return sprites[0]

        return sprites[self.frame]

    # =====================================================
    # PROCESSAR ENTRADA DO JOGADOR
    # =====================================================

    def processar_entrada(self):
        """
        Processa as teclas pressionadas para definir movimento.
        Suporta setas ou WASD.
        """

        teclas = pygame.key.get_pressed()

        # Reset de movimento
        self.movimento_x = 0
        self.movimento_y = 0

        # Verificar entradas
        esquerda_pressionado = teclas[pygame.K_LEFT] or teclas[pygame.K_a]
        direita_pressionado = teclas[pygame.K_RIGHT] or teclas[pygame.K_d]
        cima_pressionado = teclas[pygame.K_UP] or teclas[pygame.K_w]
        baixo_pressionado = teclas[pygame.K_DOWN] or teclas[pygame.K_s]

        # Movimento horizontal
        if esquerda_pressionado:
            self.movimento_x = -self.velocidade
            self.direcao = "esquerda"

        elif direita_pressionado:
            self.movimento_x = self.velocidade
            self.direcao = "direita"

        # Movimento vertical
        if cima_pressionado:
            self.movimento_y = -self.velocidade
            self.direcao = "costas"

        elif baixo_pressionado:
            self.movimento_y = self.velocidade
            self.direcao = "frente"

        # Determinar se está se movendo
        self.esta_se_movendo = (
            self.movimento_x != 0 or self.movimento_y != 0
        )

    def _sortear_direcao(self):
        """Escolhe uma direcao cardinal aleatoria."""

        return random.choice(
            [
                (-1, 0),
                (1, 0),
                (0, -1),
                (0, 1)
            ]
        )

    def processar_ia(self, alvo):
        """Alterna entre andar aleatoriamente e perseguir o alvo."""

        if self.tempo_ia <= 0:
            if self.modo_ia == "aleatorio":
                self.modo_ia = "perseguindo"
                self.tempo_ia = TEMPO_PERSEGUINDO
            else:
                self.modo_ia = "aleatorio"
                self.tempo_ia = TEMPO_MOVIMENTO_ALEATORIO
                self.direcao_aleatoria = self._sortear_direcao()

        if self.modo_ia == "aleatorio":
            direcao_x, direcao_y = self.direcao_aleatoria
            self.movimento_x = direcao_x * self.velocidade_ia
            self.movimento_y = direcao_y * self.velocidade_ia
        else:
            distancia_x = alvo.x - self.x
            distancia_y = alvo.y - self.y
            distancia = math.hypot(distancia_x, distancia_y)

            if distancia <= 40:
                self.movimento_x = 0
                self.movimento_y = 0
            else:
                self.movimento_x = distancia_x / distancia * self.velocidade_ia
                self.movimento_y = distancia_y / distancia * self.velocidade_ia

        self.tempo_ia -= 1
        self.direcao = self._obter_direcao_movimento()
        self.esta_se_movendo = (
            self.movimento_x != 0 or self.movimento_y != 0
        )

    def _obter_direcao_movimento(self):
        if abs(self.movimento_x) > abs(self.movimento_y):
            return "direita" if self.movimento_x > 0 else "esquerda"

        if self.movimento_y < 0:
            return "costas"

        return "frente"

    # =====================================================
    # APLICAR MOVIMENTO COM COLISÃO
    # =====================================================

    def aplicar_movimento(self):
        """
        Atualiza a posição do personagem com detecção de colisão.
        """

        if not self.esta_se_movendo:
            return

        # Calcular nova posição
        novo_x = self.x + self.movimento_x
        novo_y = self.y + self.movimento_y

        # Obter sprite atual para hitbox
        sprite = self.pegar_sprite()

        # Verificar colisão
        if pode_andar(
                novo_x,
                novo_y,
                sprite,
                largura_colisao=LARGURA_HITBOX,
                altura_colisao=ALTURA_HITBOX,
                deslocamento_x=DESLOCAMENTO_HITBOX_X
        ):
            self.x = novo_x
            self.y = novo_y

    def _tentar_contornar_parede(self, alvo):
        """Testa os dois lados perpendiculares ao bloqueio."""

        movimento = pygame.Vector2(self.movimento_x, self.movimento_y)
        if movimento.length_squared() == 0:
            return False

        perpendicular = pygame.Vector2(-movimento.y, movimento.x)
        perpendicular.scale_to_length(self.velocidade_ia)
        tentativas = [perpendicular, -perpendicular]
        tentativas.sort(
            key=lambda tentativa: math.hypot(
                alvo.x - (self.x + tentativa.x),
                alvo.y - (self.y + tentativa.y)
            )
        )

        sprite = self.pegar_sprite()
        for tentativa in tentativas:
            if pode_andar(
                self.x + tentativa.x,
                self.y + tentativa.y,
                sprite,
                largura_colisao=LARGURA_HITBOX,
                altura_colisao=ALTURA_HITBOX,
                deslocamento_x=DESLOCAMENTO_HITBOX_X
            ):
                self.movimento_x = tentativa.x
                self.movimento_y = tentativa.y
                return True

        return False

    def disparar_ataque(self, alvo):
        sprite_rect = self.pegar_sprite().get_rect(
            topleft=(self.x, self.y)
        )
        alvo_rect = alvo.pegar_sprite().get_rect(
            topleft=(alvo.x, alvo.y)
        )
        distancia_x = alvo_rect.centerx - sprite_rect.centerx
        distancia_y = alvo_rect.centery - sprite_rect.centery
        distancia = math.hypot(distancia_x, distancia_y)
        if distancia > ALCANCE_ATAQUE or self.tempo_ataque > 0:
            return

        direcao = pygame.Vector2(distancia_x, distancia_y)
        if direcao.length_squared() == 0:
            return

        direcao.normalize_ip()
        origem = pygame.Vector2(sprite_rect.center)
        self.ataques.append({
            "posicao": origem,
            "direcao": direcao,
            "acertou": False
        })
        self.tempo_ataque = INTERVALO_ATAQUE

    def atualizar_ataques(self, jogador, interface):
        if self.tempo_ataque > 0:
            self.tempo_ataque -= 1

        jogador_rect = jogador.pegar_sprite().get_rect(
            topleft=(jogador.x, jogador.y)
        )
        novos_ataques = []
        for ataque in self.ataques:
            ataque["posicao"] += ataque["direcao"] * VELOCIDADE_ATAQUE
            posicao = ataque["posicao"]
            ataque_rect = self.sprite_ataque.get_rect(center=posicao)

            if ataque_rect.colliderect(jogador_rect):
                if not ataque["acertou"]:
                    interface.receber_dano(
                        1,
                        jogador,
                        ataque["direcao"],
                        ataque["direcao"] * VELOCIDADE_ATAQUE
                    )
                continue

            pontos_ataque = [
                (ataque_rect.left, ataque_rect.top),
                (ataque_rect.right - 1, ataque_rect.top),
                (ataque_rect.left, ataque_rect.bottom - 1),
                (ataque_rect.right - 1, ataque_rect.bottom - 1)
            ]
            if any(eh_parede(x, y) for x, y in pontos_ataque):
                continue

            if ataque_rect.bottom >= 0 and ataque_rect.top <= 640:
                novos_ataques.append(ataque)

        self.ataques = novos_ataques

    def desenhar_ataques(self, tela):
        for ataque in self.ataques:
            tela.blit(
                self.sprite_ataque,
                self.sprite_ataque.get_rect(center=ataque["posicao"])
            )

    # =====================================================
    # ATUALIZAR ANIMAÇÃO
    # =====================================================

    def atualizar_animacao(self):
        """
        Atualiza o frame da animação baseado no movimento.
        """

        # Se não está se movendo, volta ao frame 0
        if not self.esta_se_movendo:
            self.frame = 0
            self.contador_animacao = 0
            return

        # Incrementar contador
        self.contador_animacao += 1

        # Mudar frame quando atinge velocidade de animação
        if self.contador_animacao >= self.velocidade_animacao:
            self.contador_animacao = 0
            self.frame += 1

            # Reset do frame baseado no número de sprites da direção
            sprites = self._pegar_sprites_direcao()
            if self.frame >= len(sprites):
                self.frame = 0

    # =====================================================
    # AUXILIAR: PEGAR SPRITES DA DIREÇÃO ATUAL
    # =====================================================

    def _pegar_sprites_direcao(self):
        """
        Retorna a lista de sprites da direção atual.

        Returns:
            list: Lista de sprites
        """

        if self.direcao == "costas":
            return self.costas
        elif self.direcao == "frente":
            return self.frente
        elif self.direcao == "esquerda":
            return self.esquerda
        elif self.direcao == "direita":
            return self.direita
        else:
            return self.frente

    # =====================================================
    # ATUALIZAR (CHAMAR A CADA FRAME)
    # =====================================================

    def atualizar(self, alvo=None, interface=None):
        """
        Atualiza o personagem (entrada, movimento e animação).
        Deve ser chamado a cada frame do jogo.
        """

        if alvo is None:
            self.processar_entrada()
        else:
            self.processar_ia(alvo)
        if alvo is not None:
            if not pode_andar(
                self.x + self.movimento_x,
                self.y + self.movimento_y,
                self.pegar_sprite(),
                largura_colisao=LARGURA_HITBOX,
                altura_colisao=ALTURA_HITBOX,
                deslocamento_x=DESLOCAMENTO_HITBOX_X
            ):
                self._tentar_contornar_parede(alvo)
        self.aplicar_movimento()
        if alvo is not None and interface is not None:
            self.disparar_ataque(alvo)
            self.atualizar_ataques(alvo, interface)
        self.atualizar_animacao()

    # =====================================================
    # DESENHAR
    # =====================================================

    def desenhar(self, tela):
        """
        Desenha o personagem na tela.

        Args:
            tela: pygame.Surface para desenhar
        """

        sprite = self.pegar_sprite()
        tela.blit(sprite, (self.x, self.y))

    # =====================================================
    # OBTER RECT (HITBOX)
    # =====================================================

    def obter_rect(self):
        """
        Retorna o retângulo (hitbox) do personagem.

        Returns:
            pygame.Rect: Hitbox de colisão na base do sprite
        """

        sprite = self.pegar_sprite()
        sprite_rect = sprite.get_rect(topleft=(self.x, self.y))
        hitbox = pygame.Rect(
            0,
            0,
            LARGURA_HITBOX,
            ALTURA_HITBOX
        )
        hitbox.midbottom = (
            sprite_rect.centerx + DESLOCAMENTO_HITBOX_X,
            sprite_rect.bottom
        )
        return hitbox
