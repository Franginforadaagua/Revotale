import pygame
import sys


# ==========================================
# CONFIGURAÇÕES
# ==========================================

from config import (
    LARGURA,
    ALTURA,
    FPS,
    TITULO,
    VIDA_MAXIMA
)


# ==========================================
# RECURSOS
# ==========================================

from recursos import (
    carregar_chao,
    carregar_parede,
    carregar_personagem,
    carregar_coracao,
    carregar_eren
)


# ==========================================
# SISTEMAS
# ==========================================

from jogador import Jogador
from eren import Eren

from coracao import Coracao

from interface import Interface

from mapa import desenhar_mapa


# ==========================================
# INICIAR PYGAME
# ==========================================

pygame.init()


# ==========================================
# JANELA
# ==========================================

tela = pygame.display.set_mode(
    (
        0,
        0
    ),
    pygame.FULLSCREEN
)

tela_jogo = pygame.Surface(
    (
        LARGURA,
        ALTURA
    )
)

fullscreen = True


def alternar_fullscreen():

    global tela, fullscreen

    fullscreen = not fullscreen

    if fullscreen:

        tela = pygame.display.set_mode(
            (
                0,
                0
            ),
            pygame.FULLSCREEN
        )

    else:

        tela = pygame.display.set_mode(
            (
                LARGURA,
                ALTURA
            ),
            pygame.RESIZABLE
        )


def apresentar_tela():

    largura_tela, altura_tela = tela.get_size()

    escala = min(
        largura_tela / LARGURA,
        altura_tela / ALTURA
    )

    tamanho = (
        int(LARGURA * escala),
        int(ALTURA * escala)
    )

    tela_escalada = pygame.transform.scale(
        tela_jogo,
        tamanho
    )

    tela.fill(
        (0, 0, 0)
    )

    tela.blit(
        tela_escalada,
        (
            (largura_tela - tamanho[0]) // 2,
            (altura_tela - tamanho[1]) // 2
        )
    )


pygame.display.set_caption(
    TITULO
)


# ==========================================
# CLOCK
# ==========================================

clock = pygame.time.Clock()


# ==========================================
# CARREGAR TILES
# ==========================================

chao = carregar_chao()

parede = carregar_parede()


# ==========================================
# CARREGAR PERSONAGEM
# ==========================================

(
    baixo,
    cima,
    esquerda,
    direita
) = carregar_personagem()

sprites_eren = carregar_eren()


# ==========================================
# CARREGAR CORAÇÃO
# ==========================================

sprites_coracao = (
    carregar_coracao()
)


# ==========================================
# CRIAR JOGADOR
# ==========================================

jogador = Jogador(
    baixo,
    cima,
    esquerda,
    direita,
    largura_tela=LARGURA,
    altura_tela=ALTURA
)

eren = Eren(
    *sprites_eren,
    jogador
)


# ==========================================
# CRIAR CORAÇÃO
# ==========================================

coracao = Coracao(
    sprites_coracao,
    LARGURA,
    ALTURA
)


# ==========================================
# CRIAR INTERFACE
# ==========================================

interface = Interface(
    VIDA_MAXIMA
)


# ==========================================
# LOOP PRINCIPAL
# ==========================================

rodando = True


while rodando:

    # ======================================
    # EVENTOS
    # ======================================

    for evento in pygame.event.get():

        if evento.type == pygame.QUIT:

            rodando = False

        # ==================================
        # TECLAS
        # ==================================

        if evento.type == pygame.KEYDOWN:

            if evento.key == pygame.K_F11:

                alternar_fullscreen()

            if evento.key == pygame.K_SPACE:

                coracao.ativo = (
                    not coracao.ativo
                )

    # ======================================
    # ATUALIZAR JOGADOR
    # ======================================

    jogador.atualizar()
    eren.atualizar()

    # ======================================
    # ATUALIZAR CORAÇÃO
    # ======================================

    coracao.atualizar()

    # ======================================
    # LIMPAR TELA
    # ======================================

    tela_jogo.fill(
        (0, 0, 0)
    )

    # ======================================
    # DESENHAR MAPA
    # ======================================

    desenhar_mapa(
        tela_jogo,
        chao,
        parede
    )

    # ======================================
    # DESENHAR JOGADOR
    # ======================================

    # ======================================
# PROFUNDIDADE DOS PERSONAGENS
# ======================================

    if eren.y < jogador.y:

        # Eren está acima
        # → fica atrás do jogador

        eren.desenhar(
            tela_jogo
        )

        jogador.desenhar(
            tela_jogo
        )

    else:

        # Eren está abaixo
        # → fica na frente do jogador

        jogador.desenhar(
            tela_jogo
        )

        eren.desenhar(
            tela_jogo
        )

    # ======================================
    # DESENHAR CORAÇÃO
    # ======================================

    coracao.desenhar(
        tela_jogo,
        jogador
    )

    # ======================================
    # DESENHAR HP
    # ======================================

    interface.desenhar_vida(
        tela_jogo
    )

    # ======================================
    # ATUALIZAR TELA
    # ======================================

    apresentar_tela()

    pygame.display.flip()

    # ======================================
    # FPS
    # ======================================

    clock.tick(FPS)


# ==========================================
# ENCERRAR
# ==========================================

pygame.quit()

sys.exit()
