import pygame

from config import (
    ESCALA,
    ESCALA_CORACAO,
    TAMANHO_TILE
)


# ==========================================
# CARREGAR CHÃO
# ==========================================

def carregar_chao():

    chao = pygame.image.load(
        "assets/chao.png"
    ).convert_alpha()

    chao = pygame.transform.scale(
        chao,
        (
            TAMANHO_TILE,
            TAMANHO_TILE
        )
    )

    return chao


# ==========================================
# CARREGAR PAREDE
# ==========================================

def carregar_parede():

    parede = pygame.image.load(
        "assets/parede.png"
    ).convert_alpha()

    return parede


# ==========================================
# CARREGAR SPRITES DO PERSONAGEM
# ==========================================

def carregar_personagem():

    # ======================================
    # BAIXO
    # ======================================

    baixo = [

        pygame.image.load(
            "assets/Yuri/frente1.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/Yuri/frente2.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/Yuri/frente3.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/Yuri/frente4.png"
        ).convert_alpha()
    ]

    # ======================================
    # CIMA
    # ======================================

    cima = [

        pygame.image.load(
            "assets/Yuri/cima1.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/Yuri/cima2.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/Yuri/cima3.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/Yuri/cima4.png"
        ).convert_alpha()
    ]

    # ======================================
    # ESQUERDA
    # ======================================

    esquerda = [

        pygame.image.load(
            "assets/Yuri/esquerda1.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/Yuri/esquerda2.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/Yuri/esquerda3.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/Yuri/esquerda4.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/Yuri/esquerda5.png"
        ).convert_alpha()
    ]

    # ======================================
    # DIREITA
    # ======================================

    direita = [

        pygame.image.load(
            "assets/Yuri/direita1.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/Yuri/direita2.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/Yuri/direita3.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/Yuri/direita4.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/Yuri/direita5.png"
        ).convert_alpha()
    ]

    # ======================================
    # AUMENTAR PERSONAGEM
    # ======================================

    for sprites in [
        baixo,
        cima,
        esquerda,
        direita
    ]:

        for i in range(len(sprites)):

            largura = sprites[i].get_width()
            altura = sprites[i].get_height()

            sprites[i] = pygame.transform.scale(
                sprites[i],
                (
                    largura * ESCALA,
                    altura * ESCALA
                )
            )

    return (
        baixo,
        cima,
        esquerda,
        direita
    )


def carregar_eren():

    baixo = []
    esquerda = []
    direita = []

    for nome, sprites in [
        ("frente", baixo),
        ("esquerda", esquerda),
        ("direita", direita)
    ]:

        quantidade = 5

        for indice in range(1, quantidade + 1):

            sprite = pygame.image.load(
                f"assets/Eren/{nome}{indice}.png"
            ).convert_alpha()

            largura = sprite.get_width()
            altura = sprite.get_height()

            sprites.append(
                pygame.transform.scale(
                    sprite,
                    (
                        largura * ESCALA,
                        altura * ESCALA
                    )
                )
            )

    return baixo, baixo, esquerda, direita


# ==========================================
# CARREGAR CORAÇÃO
# ==========================================

def carregar_coracao():

    coracao = [

        pygame.image.load(
            "assets/coracao/coracao1.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/coracao/coracao2.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/coracao/coracao3.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/coracao/coracao4.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/coracao/coracao5.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/coracao/coracao6.png"
        ).convert_alpha()
    ]

    # ======================================
    # AUMENTAR CORAÇÃO
    # ======================================

    for i in range(len(coracao)):

        largura = coracao[i].get_width()
        altura = coracao[i].get_height()

        coracao[i] = pygame.transform.scale(
            coracao[i],
            (
                largura * ESCALA_CORACAO,
                altura * ESCALA_CORACAO
            )
        )

    return coracao
