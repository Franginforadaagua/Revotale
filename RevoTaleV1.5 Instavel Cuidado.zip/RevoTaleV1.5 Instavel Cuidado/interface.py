import pygame

from config import ESCALA_BARRA_VIDA


class Interface:

    def __init__(
        self,
        vida_maxima
    ):

        self.vida = vida_maxima

        self.vida_maxima = vida_maxima

        self.fonte_vida = pygame.font.Font(
            None,
            32
        )

        self.sprite_icone = pygame.image.load(
            "assets/BarraVida/Icone.png"
        ).convert_alpha()

        self.sprite_borda = pygame.image.load(
            "assets/BarraVida/borda.png"
        ).convert_alpha()

        self.sprite_meio = pygame.image.load(
            "assets/BarraVida/meio.png"
        ).convert_alpha()

        self.sprite_icone = self._preparar_sprite(
            self.sprite_icone
        )

        self.sprite_borda = self._preparar_sprite(
            self.sprite_borda
        )

        self.sprite_meio = self._preparar_sprite(
            self.sprite_meio
        )

        self.inicio_barra = 10 * ESCALA_BARRA_VIDA
        self.fim_barra = 44 * ESCALA_BARRA_VIDA
        self.espaco_icone = 2 * ESCALA_BARRA_VIDA
        self.largura_barra = (
            (self.vida_maxima - 1)
            * self.sprite_meio.get_width()
            +
            2
        )
        self.altura_barra = 4 * ESCALA_BARRA_VIDA

    @staticmethod
    def _preparar_sprite(sprite):

        area = sprite.get_bounding_rect()
        sprite = sprite.subsurface(area).copy()

        return pygame.transform.scale(
            sprite,
            (
                sprite.get_width() * ESCALA_BARRA_VIDA,
                sprite.get_height() * ESCALA_BARRA_VIDA
            )
        )

    # ==========================================
    # DESENHAR VIDA
    # ==========================================

    def desenhar_vida(
        self,
        tela
    ):

        x = 20
        y = 20
        x_icone = x
        x_barra = x_icone + self.sprite_icone.get_width()
        x_barra += self.espaco_icone
        x_barra -= 5
        x_sprites = x_barra - 5
        x_sprites -= 5
        y_meio = y + (
            self.sprite_icone.get_height()
            -
            self.sprite_meio.get_height()
        ) // 2
        y_meio += 2
        y_barra = y_meio + 3
        y_borda = y + (
            self.sprite_icone.get_height()
            -
            self.sprite_borda.get_height()
        ) // 2
        y_borda += 2

        raio = self.altura_barra // 2
        x_borda = (
            x_sprites
            + (
                self.vida_maxima - 1
            ) * self.sprite_meio.get_width()
            + 2
        )
        largura_barra_desenhada = (
            x_borda
            -
            x_sprites
            +
            4
        )

        pygame.draw.rect(
            tela,
            (128, 128, 128),
            (
                x_sprites,
                y_barra,
                largura_barra_desenhada,
                self.altura_barra
            ),
            border_radius=raio
        )

        largura_vermelha = (
            self.vida
            * self.sprite_meio.get_width()
        )

        if self.vida == self.vida_maxima:
            largura_vermelha = largura_barra_desenhada

        if largura_vermelha > 0:

            pygame.draw.rect(
                tela,
                (210, 0, 0),
                (
                    x_sprites,
                    y_barra,
                    largura_vermelha,
                    self.altura_barra
                ),
                border_radius=raio
            )

            if (
                self.vida < self.vida_maxima
                and largura_vermelha > raio
            ):

                pygame.draw.rect(
                    tela,
                    (210, 0, 0),
                    (
                        x_sprites + raio,
                        y_barra,
                        largura_vermelha - raio,
                        self.altura_barra
                    )
                )

        for indice in range(self.vida_maxima):

            largura_meio = self.sprite_meio.get_width()

            if indice == self.vida_maxima - 1:
                largura_meio = 2

            x_meio = (
                x_sprites
                + indice * self.sprite_meio.get_width()
            )

            tela.blit(
                self.sprite_meio,
                (
                    x_sprites
                    + indice * self.sprite_meio.get_width(),
                    y_meio
                ),
                pygame.Rect(
                    0,
                    0,
                    largura_meio,
                    self.sprite_meio.get_height()
                )
            )

        tela.blit(
            self.sprite_icone,
            (
                x_icone,
                y
            )
        )

        tela.blit(
            self.sprite_borda,
            (
                x_borda,
                y_borda
            )
        )

        texto = (
            f"HP: "
            f"{self.vida}/"
            f"{self.vida_maxima}"
        )

        imagem_texto = (
            self.fonte_vida.render(
                texto,
                True,
                (255, 255, 255)
            )
        )

        tela.blit(
            imagem_texto,
            (
                20,
                y + self.sprite_icone.get_height() + 8
            )
        )
