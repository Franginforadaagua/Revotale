import pygame
import math

from config import (
    VELOCIDADE,
    VELOCIDADE_CTRL,
    ACELERACAO,
    DESACELERACAO
)

from colisao import pode_andar


class Jogador:

    def __init__(
        self,
        baixo,
        cima,
        esquerda,
        direita,
        mapa=None,
        largura_tela=800,
        altura_tela=600
    ):

        self.baixo = baixo
        self.cima = cima
        self.esquerda = esquerda
        self.direita = direita

        # ======================================
        # DIREÇÃO
        # ======================================

        self.direcao = "baixo"

        self.direcao_anterior = "baixo"

        self.olhando_esquerda = False

        # ======================================
        # VELOCIDADE
        # ======================================

        self.velocidade = VELOCIDADE

        self.velocidade_x = 0
        self.velocidade_y = 0

        # ======================================
        # ANIMAÇÃO
        # ======================================

        self.sequencia_baixo = [
            0,
            1,
            2,
            3
        ]

        self.sequencia_cima = [
            0,
            1,
            2,
            3
        ]

        self.sequencia_lado = [
            0,
            1,
            2,
            3,
            4
        ]

        self.indice_animacao = 0

        self.frame = 0

        self.contador_animacao = 0

        self.velocidade_animacao = 8

        # ======================================
        # POSIÇÃO INICIAL
        # ======================================

        sprite = self.baixo[0]

        self.x = (
            largura_tela
            -
            sprite.get_width()
        ) // 2

        self.y = (
            altura_tela
            -
            sprite.get_height()
        ) // 2

    # ==========================================
    # PEGAR SPRITE
    # ==========================================

    def pegar_sprite(self):

        if self.direcao == "baixo":

            if self.frame >= len(
                self.baixo
            ):

                return self.baixo[0]

            return self.baixo[
                self.frame
            ]

        elif self.direcao == "cima":

            if self.frame >= len(
                self.cima
            ):

                return self.cima[0]

            return self.cima[
                self.frame
            ]

        elif self.direcao == "esquerda":

            if self.frame >= len(
                self.esquerda
            ):

                return self.esquerda[0]

            return self.esquerda[
                self.frame
            ]

        elif self.direcao == "direita":

            if self.frame >= len(
                self.direita
            ):

                return self.direita[0]

            return self.direita[
                self.frame
            ]

        return self.baixo[0]

    # ==========================================
    # ATUALIZAR
    # ==========================================

    @staticmethod
    def _desacelerar(valor):

        if valor > 0:
            return max(
                0,
                valor - DESACELERACAO
            )

        return min(
            0,
            valor + DESACELERACAO
        )

    def _acelerar(
        self,
        valor,
        direcao,
        velocidade_maxima
    ):

        if direcao == 0:
            return self._desacelerar(valor)

        valor += direcao * ACELERACAO

        return max(
            -velocidade_maxima,
            min(
                velocidade_maxima,
                valor
            )
        )

    def atualizar(self):

        teclas = pygame.key.get_pressed()

        movendo = False

        novo_x = self.x
        novo_y = self.y

        # ======================================
        # DIREÇÃO
        # ======================================

        direcao_x = 0
        direcao_y = 0

        if teclas[pygame.K_LCTRL] or teclas[pygame.K_RCTRL]:
            velocidade_atual = VELOCIDADE_CTRL

        else:
            velocidade_atual = self.velocidade

        # ======================================
        # ESQUERDA
        # ======================================

        if (
            teclas[pygame.K_a]
            or
            teclas[pygame.K_LEFT]
        ):

            direcao_x -= 1

        # ======================================
        # DIREITA
        # ======================================

        if (
            teclas[pygame.K_d]
            or
            teclas[pygame.K_RIGHT]
        ):

            direcao_x += 1

        # ======================================
        # CIMA
        # ======================================

        if (
            teclas[pygame.K_w]
            or
            teclas[pygame.K_UP]
        ):

            direcao_y -= 1

        # ======================================
        # BAIXO
        # ======================================

        if (
            teclas[pygame.K_s]
            or
            teclas[pygame.K_DOWN]
        ):

            direcao_y += 1

        self.velocidade_x = self._acelerar(
            self.velocidade_x,
            direcao_x,
            velocidade_atual
        )

        self.velocidade_y = self._acelerar(
            self.velocidade_y,
            direcao_y,
            velocidade_atual
        )

        movimento_x = self.velocidade_x
        movimento_y = self.velocidade_y

        if movimento_x != 0 and movimento_y != 0:

            fator = max(
                1,
                math.sqrt(
                    movimento_x ** 2
                    +
                    movimento_y ** 2
                )
                /
                velocidade_atual
            )

            movimento_x /= fator
            movimento_y /= fator

        # ======================================
        # NOVA POSIÇÃO
        # ======================================

        novo_x += movimento_x
        novo_y += movimento_y

        # ======================================
        # DIREÇÃO DO SPRITE
        # ======================================

        if direcao_x < 0:

            self.direcao = "esquerda"

            self.olhando_esquerda = True

            movendo = True

        elif direcao_x > 0:

            self.direcao = "direita"

            self.olhando_esquerda = False

            movendo = True

        elif direcao_y < 0:

            self.direcao = "cima"

            movendo = True

        elif direcao_y > 0:

            self.direcao = "baixo"

            movendo = True

        # ======================================
        # COLISÃO
        # ======================================

        sprite = self.pegar_sprite()

        if pode_andar(
            novo_x,
            self.y,
            sprite
        ):

            self.x = novo_x

        else:

            self.velocidade_x = 0

        if pode_andar(
            self.x,
            novo_y,
            sprite
        ):

            self.y = novo_y

        else:

            self.velocidade_y = 0

        # ======================================
        # MUDOU DE DIREÇÃO
        # ======================================

        if (
            self.direcao
            !=
            self.direcao_anterior
        ):

            self.indice_animacao = 0

            self.frame = 0

            self.contador_animacao = 0

            self.direcao_anterior = (
                self.direcao
            )

        # ======================================
        # ANIMAÇÃO
        # ======================================

        if movendo:

            self.contador_animacao += 1

            if (
                self.contador_animacao
                >=
                self.velocidade_animacao
            ):

                self.contador_animacao = 0

                if self.direcao == "baixo":

                    sequencia = (
                        self.sequencia_baixo
                    )

                elif self.direcao == "cima":

                    sequencia = (
                        self.sequencia_cima
                    )

                else:

                    sequencia = (
                        self.sequencia_lado
                    )

                self.indice_animacao += 1

                if (
                    self.indice_animacao
                    >=
                    len(sequencia)
                ):

                    self.indice_animacao = 0

                self.frame = (
                    sequencia[
                        self.indice_animacao
                    ]
                )

        else:

            self.frame = 0

            self.indice_animacao = 0

            self.contador_animacao = 0

    # ==========================================
    # DESENHAR
    # ==========================================

    def desenhar(
        self,
        tela
    ):

        sprite = self.pegar_sprite()

        tela.blit(
            sprite,
            (
                self.x,
                self.y
            )
        )
