const revealElements = document.querySelectorAll(
    '.section, .feature-card, .pillar, .mechanic, .comparison-card, .art-preview, .art-info, .final-content'
);

revealElements.forEach(element => {
    element.classList.add('reveal');
});

const observer = new IntersectionObserver(
    entries => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
            }
        });
    },
    {
        threshold: 0.12
    }
);

revealElements.forEach(element => {
    observer.observe(element);
});


const waveBars = document.querySelectorAll('.sound-wave i');

waveBars.forEach((bar, index) => {
    bar.style.animationDuration = `${0.6 + (index % 5) * 0.12}s`;
});


window.addEventListener('scroll', () => {
    const hero = document.querySelector('.hero');
    const scroll = window.scrollY;

    if (scroll < window.innerHeight) {
        hero.style.backgroundPositionY = `${scroll * 0.2}px`;
    }
});


document.querySelectorAll('a[href^="#"]').forEach(link => {
    link.addEventListener('click', event => {
        const target = document.querySelector(link.getAttribute('href'));

        if (!target) return;

        event.preventDefault();

        target.scrollIntoView({
            behavior: 'smooth',
            block: 'start'
        });
    });
});