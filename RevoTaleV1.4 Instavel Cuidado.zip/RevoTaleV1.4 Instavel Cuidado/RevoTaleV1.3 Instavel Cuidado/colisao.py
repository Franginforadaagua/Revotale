import pygame

from config import TAMANHO_TILE

from mapa import MAPA_PAREDE


# ==========================================
# VERIFICAR SE É PAREDE
# ==========================================

def eh_parede(px, py):

    coluna = int(
        px // TAMANHO_TILE
    )

    linha = int(
        py // TAMANHO_TILE
    )


    # ======================================
    # FORA DO MAPA
    # ======================================

    if linha < 0:
        return True

    if linha >= len(MAPA_PAREDE):
        return True

    if coluna < 0:
        return True

    if coluna >= len(MAPA_PAREDE[linha]):
        return True


    # ======================================
    # VERIFICAR TILE
    # ======================================

    if MAPA_PAREDE[linha][coluna] == 1:

        return True


    return False


# ==========================================
# COLISÃO DO JOGADOR
# ==========================================

def pode_andar(
    novo_x,
    novo_y,
    sprite
):

    largura = sprite.get_width()
    altura = sprite.get_height()


    # ======================================
    # HITBOX DOS PÉS
    # ======================================

    largura_colisao = int(
        largura * 0.55
    )

    altura_colisao = int(
        altura * 0.20
    )


    # ======================================
    # POSIÇÃO DA HITBOX
    # ======================================

    colisao_x = (
        novo_x
        +
        (largura - largura_colisao) // 2
    )

    colisao_y = (
        novo_y
        +
        altura
        -
        altura_colisao
        -
        5
    )


    hitbox = pygame.Rect(
        colisao_x,
        colisao_y,
        largura_colisao,
        altura_colisao
    )


    # ======================================
    # PONTOS DOS PÉS
    # ======================================

    pontos = [

        # Pé esquerdo
        (
            hitbox.left,
            hitbox.bottom - 1
        ),

        # Pé direito
        (
            hitbox.right - 1,
            hitbox.bottom - 1
        ),

        # Centro
        (
            hitbox.centerx,
            hitbox.bottom - 1
        ),

        # Parte superior esquerda
        (
            hitbox.left,
            hitbox.top
        ),

        # Parte superior direita
        (
            hitbox.right - 1,
            hitbox.top
        )
    ]


    # ======================================
    # VERIFICAR CADA PONTO
    # ======================================

    for px, py in pontos:

        if eh_parede(
            px,
            py
        ):

            return False


    return True