import pygame

from config import (
    ESCALA,
    ESCALA_CORACAO
)


# ==========================================
# CARREGAR CHÃO
# ==========================================

def carregar_chao():

    chao = pygame.image.load(
        "assets/chao.png"
    ).convert_alpha()

    return chao


# ==========================================
# CARREGAR PAREDE
# ==========================================

def carregar_parede():

    parede = pygame.image.load(
        "assets/parede.png"
    ).convert_alpha()

    return parede


# ==========================================
# CARREGAR SPRITES DO PERSONAGEM
# ==========================================

def carregar_personagem():

    # ======================================
    # BAIXO
    # ======================================

    baixo = [

        pygame.image.load(
            "assets/frente1.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/frente2.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/frente3.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/frente4.png"
        ).convert_alpha()
    ]


    # ======================================
    # CIMA
    # ======================================

    cima = [

        pygame.image.load(
            "assets/cima1.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/cima2.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/cima3.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/cima4.png"
        ).convert_alpha()
    ]


    # ======================================
    # ESQUERDA
    # ======================================

    esquerda = [

        pygame.image.load(
            "assets/esquerda1.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/esquerda2.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/esquerda3.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/esquerda4.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/esquerda5.png"
        ).convert_alpha()
    ]


    # ======================================
    # DIREITA
    # ======================================

    direita = [

        pygame.image.load(
            "assets/direita1.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/direita2.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/direita3.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/direita4.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/direita5.png"
        ).convert_alpha()
    ]


    # ======================================
    # AUMENTAR PERSONAGEM
    # ======================================

    for sprites in [
        baixo,
        cima,
        esquerda,
        direita
    ]:

        for i in range(len(sprites)):

            largura = sprites[i].get_width()
            altura = sprites[i].get_height()

            sprites[i] = pygame.transform.scale(
                sprites[i],
                (
                    largura * ESCALA,
                    altura * ESCALA
                )
            )


    return (
        baixo,
        cima,
        esquerda,
        direita
    )


# ==========================================
# CARREGAR CORAÇÃO
# ==========================================

def carregar_coracao():

    coracao = [

        pygame.image.load(
            "assets/coracao/coracao1.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/coracao/coracao2.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/coracao/coracao3.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/coracao/coracao4.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/coracao/coracao5.png"
        ).convert_alpha(),

        pygame.image.load(
            "assets/coracao/coracao6.png"
        ).convert_alpha()
    ]


    # ======================================
    # AUMENTAR CORAÇÃO
    # ======================================

    for i in range(len(coracao)):

        largura = coracao[i].get_width()
        altura = coracao[i].get_height()

        coracao[i] = pygame.transform.scale(
            coracao[i],
            (
                largura * ESCALA_CORACAO,
                altura * ESCALA_CORACAO
            )
        )


    return coracao