import pygame


class Interface:

    def __init__(
        self,
        vida_maxima
    ):

        self.vida = vida_maxima

        self.vida_maxima = vida_maxima

        self.fonte_vida = pygame.font.Font(
            None,
            32
        )


    # ==========================================
    # DESENHAR VIDA
    # ==========================================

    def desenhar_vida(
        self,
        tela
    ):

        texto = (
            f"HP: "
            f"{self.vida}/"
            f"{self.vida_maxima}"
        )


        imagem_texto = (
            self.fonte_vida.render(
                texto,
                True,
                (255, 255, 255)
            )
        )


        tela.blit(
            imagem_texto,
            (20, 20)
        )