import pygame
import sys

pygame.init()

# ==========================================
# CONFIGURAÇÕES
# ==========================================

LARGURA = 800
ALTURA = 600
FPS = 60

tela = pygame.display.set_mode((LARGURA, ALTURA))
pygame.display.set_caption("Jogo inspirado em Undertale")

clock = pygame.time.Clock()

# ==========================================
# ESCURECIMENTO DO MODO CORAÇÃO
# ==========================================

escurecimento = pygame.Surface((LARGURA, ALTURA))
escurecimento.fill((0, 0, 0))
alpha_escurecimento = 0

# ==========================================
# CONFIGURAÇÕES DO PERSONAGEM
# ==========================================

velocidade = 4

ESCALA = 3

direcao = "baixo"

olhando_esquerda = False

direcao_anterior = "baixo"

# ==========================================
# MODO CORAÇÃO
# ==========================================

coracao_ativo = True

# ==========================================
# VIDA
# ==========================================

vida_coracao = 20
vida_maxima = 20


# ==========================================
# CARREGAR CENÁRIO
# ==========================================

mapa = pygame.image.load(
    "cenarios/teste.png"
).convert_alpha()

mapa = pygame.transform.scale(
    mapa,
    (LARGURA, ALTURA)
)


# ==========================================
# CARREGAR SPRITES
# ==========================================

baixo = [
    pygame.image.load("assets/frente1.png").convert_alpha(),
    pygame.image.load("assets/frente2.png").convert_alpha(),
    pygame.image.load("assets/frente3.png").convert_alpha(),
    pygame.image.load("assets/frente4.png").convert_alpha()
]


cima = [
    pygame.image.load("assets/cima1.png").convert_alpha(),
    pygame.image.load("assets/cima2.png").convert_alpha(),
    pygame.image.load("assets/cima3.png").convert_alpha(),
    pygame.image.load("assets/cima4.png").convert_alpha()
]


esquerda = [
    pygame.image.load("assets/esquerda1.png").convert_alpha(),
    pygame.image.load("assets/esquerda2.png").convert_alpha(),
    pygame.image.load("assets/esquerda3.png").convert_alpha(),
    pygame.image.load("assets/esquerda4.png").convert_alpha(),
    pygame.image.load("assets/esquerda5.png").convert_alpha(),
]

direita = [
    pygame.image.load("assets/direita1.png").convert_alpha(),
    pygame.image.load("assets/direita2.png").convert_alpha(),
    pygame.image.load("assets/direita3.png").convert_alpha(),
    pygame.image.load("assets/direita4.png").convert_alpha(),
    pygame.image.load("assets/direita5.png").convert_alpha(),
]

# ==========================================
# SPRITES DO CORAÇÃO
# ==========================================

coracao = [
    pygame.image.load("assets/coracao/coracao1.png").convert_alpha(),
    pygame.image.load("assets/coracao/coracao2.png").convert_alpha(),
    pygame.image.load("assets/coracao/coracao3.png").convert_alpha(),
    pygame.image.load("assets/coracao/coracao4.png").convert_alpha(),
    pygame.image.load("assets/coracao/coracao5.png").convert_alpha(),
    pygame.image.load("assets/coracao/coracao6.png").convert_alpha()
]


# ==========================================
# AUMENTAR SPRITES
# ==========================================

for sprites in [baixo, cima, esquerda, direita]:

    for i in range(len(sprites)):

        largura = sprites[i].get_width()
        altura = sprites[i].get_height()

        sprites[i] = pygame.transform.scale(
            sprites[i],
            (
                largura * ESCALA,
                altura * ESCALA
            )
        )

ESCALA_CORACAO = 3

for i in range(len(coracao)):
    largura = coracao[i].get_width()
    altura = coracao[i].get_height()

    coracao[i] = pygame.transform.scale(
        coracao[i],
        (
            largura * ESCALA_CORACAO,
            altura * ESCALA_CORACAO
        )
    )


# ==========================================
# SPAWN NO CENTRO
# ==========================================

sprite_inicial = baixo[0]

x = (LARGURA - sprite_inicial.get_width()) // 2
y = (ALTURA - sprite_inicial.get_height()) // 2

# ==========================================
# FONTE DA VIDA
# ==========================================

fonte_vida = pygame.font.Font(None, 32)

# ==========================================
# ANIMAÇÕES
# ==========================================

# BAIXO
# 1 -> 2 -> 1 -> 3

sequencia_baixo = [
    0,
    1,
    2,
    3
]


# CIMA
# 1 -> 2 -> 1 -> 3

sequencia_cima = [
    0,
    1,
    2,
    3
]


# LADO
# 1 -> 2 -> 1 -> 2

sequencia_lado = [
    0,
    1,
    2,
    3,
    4
]


# ==========================================
# CONTROLE DA ANIMAÇÃO
# ==========================================

indice_animacao = 0

frame = 0

contador_animacao = 0

velocidade_animacao = 8


# ==========================================
# PEGAR SPRITE
# ==========================================

def pegar_sprite():

    if direcao == "baixo":

        if frame >= len(baixo):
            return baixo[0]

        return baixo[frame]

    elif direcao == "cima":

        if frame >= len(cima):
            return cima[0]

        return cima[frame]

    elif direcao == "esquerda":

        if frame >= len(esquerda):
            return esquerda[0]

        return esquerda[frame]

    elif direcao == "direita":

        if frame >= len(direita):
            return direita[0]

        return direita[frame]

    return baixo[0]


# ==========================================
# VERIFICAR SE É ROXO
# ==========================================

def eh_roxo(cor):

    r = cor[0]
    g = cor[1]
    b = cor[2]

    # Detecta roxo
    #
    # Muito vermelho
    # Pouco verde
    # Muito azul

    if r > 80 and b > 80 and g < 100:

        return True

    return False


# ==========================================
# COLISÃO
# ==========================================

def pode_andar(novo_x, novo_y):

    sprite = pegar_sprite()

    largura = sprite.get_width()
    altura = sprite.get_height()

    # ======================================
    # CAIXA DE COLISÃO DOS PÉS
    # ======================================

    largura_colisao = int(largura * 0.55)

    altura_colisao = int(altura * 0.20)

    # Centraliza a colisão horizontalmente
    colisao_x = novo_x + (largura - largura_colisao) // 2

    # Coloca a colisão na parte inferior
    colisao_y = novo_y + altura - altura_colisao - 5

    hitbox = pygame.Rect(
        colisao_x,
        colisao_y,
        largura_colisao,
        altura_colisao
    )

    # ======================================
    # PONTOS DA HITBOX
    # ======================================

    pontos = [

        # Pé esquerdo
        (hitbox.left, hitbox.bottom - 1),

        # Pé direito
        (hitbox.right - 1, hitbox.bottom - 1),

        # Centro dos pés
        (hitbox.centerx, hitbox.bottom - 1),

        # Parte de cima da hitbox
        (hitbox.left, hitbox.top),
        (hitbox.right - 1, hitbox.top)

    ]

    # ======================================
    # VERIFICAR COLISÃO
    # ======================================

    for px, py in pontos:

        if 0 <= px < LARGURA and 0 <= py < ALTURA:

            cor = mapa.get_at(
                (
                    int(px),
                    int(py)
                )
            )

            # Verifica se é parede roxa

            if cor[3] > 0 and eh_roxo(cor):

                return False

    return True

# ==========================================
# DESENHAR VIDA
# ==========================================


def desenhar_vida():

    texto = f"HP: {vida_coracao}/{vida_maxima}"

    imagem_texto = fonte_vida.render(
        texto,
        True,
        (255, 255, 255)
    )

    tela.blit(
        imagem_texto,
        (20, 20)
    )

# ==========================================
# LOOP PRINCIPAL
# ==========================================


rodando = True

indice_coracao = 0
contador_coracao = 0
velocidade_coracao = 8

coracao_ativo = False

alpha_escurecimento = 0

while rodando:

    # ======================================
    # EVENTOS
    # ======================================

    for evento in pygame.event.get():

        if evento.type == pygame.QUIT:
            rodando = False

        if evento.type == pygame.KEYDOWN:

            if evento.key == pygame.K_SPACE:
                coracao_ativo = not coracao_ativo

    # ======================================
    # TECLAS
    # ======================================

    teclas = pygame.key.get_pressed()

    movendo = False

    novo_x = x
    novo_y = y

    # ======================================
    # CALCULAR DIREÇÃO
    # ======================================

    direcao_x = 0
    direcao_y = 0

    # Horizontal
    if teclas[pygame.K_a] or teclas[pygame.K_LEFT]:
        direcao_x -= 1

    if teclas[pygame.K_d] or teclas[pygame.K_RIGHT]:
        direcao_x += 1

    # Vertical
    if teclas[pygame.K_w] or teclas[pygame.K_UP]:
        direcao_y -= 1

    if teclas[pygame.K_s] or teclas[pygame.K_DOWN]:
        direcao_y += 1

    # ======================================
    # NORMALIZAR DIAGONAL
    # ======================================

    if direcao_x != 0 and direcao_y != 0:

        fator = velocidade / (2 ** 0.5)

        movimento_x = direcao_x * fator
        movimento_y = direcao_y * fator

    else:

        movimento_x = direcao_x * velocidade
        movimento_y = direcao_y * velocidade

    # ======================================
    # APLICAR MOVIMENTO
    # ======================================

    novo_x += movimento_x
    novo_y += movimento_y

    # ======================================
    # DEFINIR SPRITE
    # ======================================

    if direcao_x < 0:

        direcao = "esquerda"
        olhando_esquerda = True
        movendo = True

    elif direcao_x > 0:

        direcao = "direita"
        olhando_esquerda = False
        movendo = True

    elif direcao_y < 0:

        direcao = "cima"
        movendo = True

    elif direcao_y > 0:

        direcao = "baixo"
        movendo = True

    # ======================================
    # COLISÃO
    # ======================================

    if pode_andar(novo_x, novo_y):

        x = novo_x
        y = novo_y

    # ======================================
    # MUDOU DE DIREÇÃO
    # ======================================

    if direcao != direcao_anterior:

        indice_animacao = 0

        frame = 0

        contador_animacao = 0

        direcao_anterior = direcao

    # ======================================
    # ANIMAÇÃO
    # ======================================

    if movendo:

        contador_animacao += 1

        if contador_animacao >= velocidade_animacao:

            contador_animacao = 0

            if direcao == "baixo":

                sequencia = sequencia_baixo

            elif direcao == "cima":

                sequencia = sequencia_cima

            else:

                sequencia = sequencia_lado

            indice_animacao += 1

            if indice_animacao >= len(sequencia):

                indice_animacao = 0

            frame = sequencia[indice_animacao]

    else:

        # IDLE

        frame = 0

        indice_animacao = 0

        contador_animacao = 0

    # ======================================
    # CORACAO
    # ======================================

    contador_coracao += 1

    if contador_coracao >= velocidade_coracao:
        contador_coracao = 0

        indice_coracao += 1

        if indice_coracao >= len(coracao):
            indice_coracao = 0

    # ======================================
    # PEGAR SPRITE
    # ======================================

    sprite = pegar_sprite()

    # ==========================================
    # TRANSIÇÃO DO ESCURECIMENTO
    # ==========================================

    if coracao_ativo:
        if alpha_escurecimento < 150:
            alpha_escurecimento += 5

    else:
        if alpha_escurecimento > 0:
            alpha_escurecimento -= 5

    escurecimento.set_alpha(alpha_escurecimento)

    # ======================================
    # DESENHAR CENÁRIO
    # ======================================

    tela.fill((0, 0, 0))

    tela.blit(
        mapa,
        (0, 0)
    )

    # ======================================
    # DESENHAR PERSONAGEM
    # ======================================

    tela.blit(
        sprite,
        (x, y)
    )

    # ======================================
    # MODO CORAÇÃO
    # ======================================

    if alpha_escurecimento > 0:

        tela.blit(
            escurecimento,
            (0, 0)
        )

        sprite_coracao = coracao[indice_coracao].copy()

        coracao_x = x + (sprite.get_width() - sprite_coracao.get_width()) // 2
        coracao_y = y + (sprite.get_height() -
                         sprite_coracao.get_height()) // 2

        sprite_coracao.set_alpha(alpha_escurecimento*2)

        tela.blit(
            sprite_coracao,
            (coracao_x, coracao_y)
        )

    desenhar_vida()

    # ======================================
    # ATUALIZAR
    # ======================================

    pygame.display.flip()

    clock.tick(FPS)


# ==========================================
# ENCERRAR
# ==========================================

pygame.quit()
sys.exit()
