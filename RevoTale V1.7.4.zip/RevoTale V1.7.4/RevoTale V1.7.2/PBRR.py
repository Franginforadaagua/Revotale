import pygame
from config import TAMANHO_TILE
from colisao import pode_andar


# =========================================================
# CONFIGURAÇÕES
# =========================================================

VELOCIDADE = 5
VELOCIDADE_ANIMACAO = 8


# =========================================================
# CLASSE PBRR (PERSONAGEM CONTROLÁVEL)
# =========================================================

class PBRR:
    """
    Classe para controlar um personagem com movimento livre,
    animações em 4 direções e colisão com o mapa.
    """

    def __init__(
        self,
        frente,
        costas,
        esquerda,
        direita,
        x,
        y
    ):
        """
        Inicializa o personagem PBRR.
        
        Args:
            frente: Lista de sprites para andar para frente
            costas: Lista de sprites para andar para trás
            esquerda: Lista de sprites para andar para esquerda
            direita: Lista de sprites para andar para direita
            x: Posição inicial X
            y: Posição inicial Y
        """

        # =================================================
        # SPRITES
        # =================================================

        self.frente = frente
        self.costas = costas
        self.esquerda = esquerda
        self.direita = direita

        # =================================================
        # POSIÇÃO
        # =================================================

        self.x = x
        self.y = y

        # =================================================
        # DIREÇÃO
        # =================================================

        self.direcao = "frente"
        self.direcao_anterior = "frente"

        # =================================================
        # MOVIMENTO
        # =================================================

        self.velocidade = VELOCIDADE

        self.movimento_x = 0
        self.movimento_y = 0

        # =================================================
        # ANIMAÇÃO
        # =================================================

        self.frame = 0
        self.contador_animacao = 0
        self.velocidade_animacao = VELOCIDADE_ANIMACAO

        # =================================================
        # ESTADO
        # =================================================

        self.esta_se_movendo = False


    # =====================================================
    # PEGAR SPRITE ATUAL
    # =====================================================

    def pegar_sprite(self):
        """
        Retorna o sprite atual baseado na direção e frame.
        
        Returns:
            pygame.Surface: Imagem do sprite
        """

        # Escolher lista de sprites baseado na direção
        if self.direcao == "costas":
            sprites = self.costas
        elif self.direcao == "frente":
            sprites = self.frente
        elif self.direcao == "esquerda":
            sprites = self.esquerda
        elif self.direcao == "direita":
            sprites = self.direita
        else:
            sprites = self.frente

        # Validar índice do frame
        if self.frame >= len(sprites):
            self.frame = 0
            return sprites[0]

        return sprites[self.frame]


    # =====================================================
    # PROCESSAR ENTRADA DO JOGADOR
    # =====================================================

    def processar_entrada(self):
        """
        Processa as teclas pressionadas para definir movimento.
        Suporta setas ou WASD.
        """

        teclas = pygame.key.get_pressed()

        # Reset de movimento
        self.movimento_x = 0
        self.movimento_y = 0

        # Verificar entradas
        esquerda_pressionado = teclas[pygame.K_LEFT] or teclas[pygame.K_a]
        direita_pressionado = teclas[pygame.K_RIGHT] or teclas[pygame.K_d]
        cima_pressionado = teclas[pygame.K_UP] or teclas[pygame.K_w]
        baixo_pressionado = teclas[pygame.K_DOWN] or teclas[pygame.K_s]

        # Movimento horizontal
        if esquerda_pressionado:
            self.movimento_x = -self.velocidade
            self.direcao = "esquerda"

        elif direita_pressionado:
            self.movimento_x = self.velocidade
            self.direcao = "direita"

        # Movimento vertical
        if cima_pressionado:
            self.movimento_y = -self.velocidade
            self.direcao = "costas"

        elif baixo_pressionado:
            self.movimento_y = self.velocidade
            self.direcao = "frente"

        # Determinar se está se movendo
        self.esta_se_movendo = (
            self.movimento_x != 0 or self.movimento_y != 0
        )


    # =====================================================
    # APLICAR MOVIMENTO COM COLISÃO
    # =====================================================

    def aplicar_movimento(self):
        """
        Atualiza a posição do personagem com detecção de colisão.
        """

        if not self.esta_se_movendo:
            return

        # Calcular nova posição
        novo_x = self.x + self.movimento_x
        novo_y = self.y + self.movimento_y

        # Obter sprite atual para hitbox
        sprite = self.pegar_sprite()

        # Verificar colisão
        if pode_andar(novo_x, novo_y, sprite):
            self.x = novo_x
            self.y = novo_y


    # =====================================================
    # ATUALIZAR ANIMAÇÃO
    # =====================================================

    def atualizar_animacao(self):
        """
        Atualiza o frame da animação baseado no movimento.
        """

        # Se não está se movendo, volta ao frame 0
        if not self.esta_se_movendo:
            self.frame = 0
            self.contador_animacao = 0
            return

        # Incrementar contador
        self.contador_animacao += 1

        # Mudar frame quando atinge velocidade de animação
        if self.contador_animacao >= self.velocidade_animacao:
            self.contador_animacao = 0
            self.frame += 1

            # Reset do frame baseado no número de sprites da direção
            sprites = self._pegar_sprites_direcao()
            if self.frame >= len(sprites):
                self.frame = 0


    # =====================================================
    # AUXILIAR: PEGAR SPRITES DA DIREÇÃO ATUAL
    # =====================================================

    def _pegar_sprites_direcao(self):
        """
        Retorna a lista de sprites da direção atual.
        
        Returns:
            list: Lista de sprites
        """

        if self.direcao == "costas":
            return self.costas
        elif self.direcao == "frente":
            return self.frente
        elif self.direcao == "esquerda":
            return self.esquerda
        elif self.direcao == "direita":
            return self.direita
        else:
            return self.frente


    # =====================================================
    # ATUALIZAR (CHAMAR A CADA FRAME)
    # =====================================================

    def atualizar(self):
        """
        Atualiza o personagem (entrada, movimento e animação).
        Deve ser chamado a cada frame do jogo.
        """

        self.processar_entrada()
        self.aplicar_movimento()
        self.atualizar_animacao()


    # =====================================================
    # DESENHAR
    # =====================================================

    def desenhar(self, tela):
        """
        Desenha o personagem na tela.
        
        Args:
            tela: pygame.Surface para desenhar
        """

        sprite = self.pegar_sprite()
        tela.blit(sprite, (self.x, self.y))


    # =====================================================
    # OBTER RECT (HITBOX)
    # =====================================================

    def obter_rect(self):
        """
        Retorna o retângulo (hitbox) do personagem.
        
        Returns:
            pygame.Rect: Retângulo da posição e tamanho
        """

        sprite = self.pegar_sprite()
        return sprite.get_rect(topleft=(self.x, self.y))