import pygame
import sys

pygame.init()

# ==========================================
# CONFIGURAÇÕES
# ==========================================

LARGURA = 800
ALTURA = 600
FPS = 60

tela = pygame.display.set_mode((LARGURA, ALTURA))
pygame.display.set_caption("Jogo inspirado em Undertale")

clock = pygame.time.Clock()


# ==========================================
# CONFIGURAÇÕES DO PERSONAGEM
# ==========================================

velocidade = 4

ESCALA = 3

direcao = "baixo"

olhando_esquerda = False

direcao_anterior = "baixo"


# ==========================================
# CARREGAR CENÁRIO
# ==========================================

mapa = pygame.image.load(
    "cenarios/teste.png"
).convert_alpha()

mapa = pygame.transform.scale(
    mapa,
    (LARGURA, ALTURA)
)


# ==========================================
# CARREGAR SPRITES
# ==========================================

baixo = [
    pygame.image.load("assets/baixo.png").convert_alpha(),
    pygame.image.load("assets/baixo1.png").convert_alpha(),
    pygame.image.load("assets/baixo2.png").convert_alpha()
]


cima = [
    pygame.image.load("assets/cima.png").convert_alpha(),
    pygame.image.load("assets/cima1.png").convert_alpha(),
    pygame.image.load("assets/cima2.png").convert_alpha()
]


esquerda = [
    pygame.image.load("assets/esquerda.png").convert_alpha(),
]

direita = [
    pygame.image.load("assets/direita.png").convert_alpha(),
]


# ==========================================
# AUMENTAR SPRITES
# ==========================================

for sprites in [baixo, cima, esquerda, direita]:

    for i in range(len(sprites)):

        largura = sprites[i].get_width()
        altura = sprites[i].get_height()

        sprites[i] = pygame.transform.scale(
            sprites[i],
            (
                largura * ESCALA,
                altura * ESCALA
            )
        )


# ==========================================
# SPAWN NO CENTRO
# ==========================================

sprite_inicial = baixo[0]

x = (LARGURA - sprite_inicial.get_width()) // 2
y = (ALTURA - sprite_inicial.get_height()) // 2


# ==========================================
# ANIMAÇÕES
# ==========================================

# BAIXO
# 1 -> 2 -> 1 -> 3

sequencia_baixo = [
    0,
    1,
    0,
    2
]


# CIMA
# 1 -> 2 -> 1 -> 3

sequencia_cima = [
    0,
    1,
    0,
    2
]


# LADO
# 1 -> 2 -> 1 -> 2

sequencia_lado = [
    0,
    1
]


# ==========================================
# CONTROLE DA ANIMAÇÃO
# ==========================================

indice_animacao = 0

frame = 0

contador_animacao = 0

velocidade_animacao = 8


# ==========================================
# PEGAR SPRITE
# ==========================================

def pegar_sprite():

    if direcao == "baixo":

        if frame >= len(baixo):
            return baixo[0]

        return baixo[frame]


    elif direcao == "cima":

        if frame >= len(cima):
            return cima[0]

        return cima[frame]


    elif direcao == "esquerda":

        if frame >= len(esquerda):
            return esquerda[0]

        return esquerda[frame]

    elif direcao == "direita":
    
            if frame >= len(direita):
                return direita[0]
    
            return direita[frame]


    return baixo[0]


# ==========================================
# VERIFICAR SE É ROXO
# ==========================================

def eh_roxo(cor):

    r = cor[0]
    g = cor[1]
    b = cor[2]

    # Detecta roxo
    #
    # Muito vermelho
    # Pouco verde
    # Muito azul

    if r > 80 and b > 80 and g < 100:

        return True

    return False


# ==========================================
# COLISÃO
# ==========================================

def pode_andar(novo_x, novo_y):

    sprite = pegar_sprite()

    largura = sprite.get_width()
    altura = sprite.get_height()

    # ======================================
    # CAIXA DE COLISÃO DOS PÉS
    # ======================================

    largura_colisao = int(largura * 0.55)

    altura_colisao = int(altura * 0.20)

    # Centraliza a colisão horizontalmente
    colisao_x = novo_x + (largura - largura_colisao) // 2

    # Coloca a colisão na parte inferior
    colisao_y = novo_y + altura - altura_colisao - 5

    hitbox = pygame.Rect(
        colisao_x,
        colisao_y,
        largura_colisao,
        altura_colisao
    )

    # ======================================
    # PONTOS DA HITBOX
    # ======================================

    pontos = [

        # Pé esquerdo
        (hitbox.left, hitbox.bottom - 1),

        # Pé direito
        (hitbox.right - 1, hitbox.bottom - 1),

        # Centro dos pés
        (hitbox.centerx, hitbox.bottom - 1),

        # Parte de cima da hitbox
        (hitbox.left, hitbox.top),
        (hitbox.right - 1, hitbox.top)

    ]

    # ======================================
    # VERIFICAR COLISÃO
    # ======================================

    for px, py in pontos:

        if 0 <= px < LARGURA and 0 <= py < ALTURA:

            cor = mapa.get_at(
                (
                    int(px),
                    int(py)
                )
            )

            # Verifica se é parede roxa

            if cor[3] > 0 and eh_roxo(cor):

                return False

    return True


# ==========================================
# LOOP PRINCIPAL
# ==========================================

rodando = True

while rodando:

    # ======================================
    # EVENTOS
    # ======================================

    for evento in pygame.event.get():

        if evento.type == pygame.QUIT:

            rodando = False


    # ======================================
    # TECLAS
    # ======================================

    teclas = pygame.key.get_pressed()

    movendo = False

    novo_x = x
    novo_y = y


    # ======================================
    # CIMA
    # ======================================

    if teclas[pygame.K_w] or teclas[pygame.K_UP]:

        novo_y -= velocidade

        direcao = "cima"

        movendo = True


    # ======================================
    # BAIXO
    # ======================================

    elif teclas[pygame.K_s] or teclas[pygame.K_DOWN]:

        novo_y += velocidade

        direcao = "baixo"

        movendo = True


    # ======================================
    # ESQUERDA
    # ======================================

    elif teclas[pygame.K_a] or teclas[pygame.K_LEFT]:

        novo_x -= velocidade

        direcao = "esquerda"

        olhando_esquerda = True

        movendo = True


    # ======================================
    # DIREITA
    # ======================================

    elif teclas[pygame.K_d] or teclas[pygame.K_RIGHT]:

        novo_x += velocidade

        direcao = "direita"

        olhando_esquerda = False

        movendo = True


    # ======================================
    # COLISÃO
    # ======================================

    if pode_andar(novo_x, novo_y):

        x = novo_x
        y = novo_y


    # ======================================
    # MUDOU DE DIREÇÃO
    # ======================================

    if direcao != direcao_anterior:

        indice_animacao = 0

        frame = 0

        contador_animacao = 0

        direcao_anterior = direcao


    # ======================================
    # ANIMAÇÃO
    # ======================================

    if movendo:

        contador_animacao += 1


        if contador_animacao >= velocidade_animacao:

            contador_animacao = 0


            if direcao == "baixo":

                sequencia = sequencia_baixo

            elif direcao == "cima":

                sequencia = sequencia_cima

            else:

                sequencia = sequencia_lado


            indice_animacao += 1


            if indice_animacao >= len(sequencia):

                indice_animacao = 0


            frame = sequencia[indice_animacao]


    else:

        # IDLE

        frame = 0

        indice_animacao = 0

        contador_animacao = 0


    # ======================================
    # PEGAR SPRITE
    # ======================================

    sprite = pegar_sprite()


    # ======================================
    # VIRAR PARA ESQUERDA
    # ======================================


    # ======================================
    # DESENHAR CENÁRIO
    # ======================================

    tela.fill((0, 0, 0))

    tela.blit(
        mapa,
        (0, 0)
    )


    # ======================================
    # DESENHAR PERSONAGEM
    # ======================================

    tela.blit(
        sprite,
        (x, y)
    )


    # ======================================
    # ATUALIZAR
    # ======================================

    pygame.display.flip()

    clock.tick(FPS)


# ==========================================
# ENCERRAR
# ==========================================

pygame.quit()
sys.exit()