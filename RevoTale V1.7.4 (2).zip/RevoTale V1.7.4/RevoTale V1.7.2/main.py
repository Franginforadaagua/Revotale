import pygame
import sys


# ==========================================
# CONFIGURAÇÕES
# ==========================================

from config import (
    LARGURA,
    ALTURA,
    FPS,
    TITULO,
    VIDA_MAXIMA
)


# ==========================================
# TELA INICIAL
# ==========================================

from tela_inicial import tela_inicial


# ==========================================
# CENAS
# ==========================================

from cenas import mostrar_cenas


# ==========================================
# RECURSOS
# ==========================================

from recursos import (
    carregar_chao,
    carregar_parede,
    carregar_personagem,
    carregar_coracao,
    carregar_eren,
    carregar_pbrr
)


# ==========================================
# JOGADOR
# ==========================================

from jogador import Jogador


# ==========================================
# EREN
# ==========================================

from eren import Eren


# ==========================================
# CORAÇÃO
# ==========================================

from coracao import Coracao


# ==========================================
# PBRR
# ==========================================

from PBRR import PBRR


# ==========================================
# INTERFACE
# ==========================================

from interface import Interface


# ==========================================
# MAPA
# ==========================================

from mapa import desenhar_mapa


# ==========================================
# CAIXA DE DIÁLOGO
# ==========================================

from caixa_dialogo import CaixaDialogo


# ==========================================
# INICIAR PYGAME
# ==========================================

pygame.init()


# ==========================================
# JANELA
# ==========================================

tela = pygame.display.set_mode(
    (
        0,
        0
    ),
    pygame.FULLSCREEN
)

fullscreen = True


# ==========================================
# TELA INTERNA DO JOGO
# ==========================================

tela_jogo = pygame.Surface(
    (
        LARGURA,
        ALTURA
    )
)


# ==========================================
# TÍTULO
# ==========================================

pygame.display.set_caption(
    TITULO
)


# ==========================================
# FUNÇÃO FULLSCREEN
# ==========================================

def alternar_fullscreen():

    global tela
    global fullscreen

    fullscreen = not fullscreen

    if fullscreen:

        tela = pygame.display.set_mode(
            (
                0,
                0
            ),
            pygame.FULLSCREEN
        )

    else:

        tela = pygame.display.set_mode(
            (
                LARGURA,
                ALTURA
            ),
            pygame.RESIZABLE
        )


# ==========================================
# APRESENTAR TELA
# ==========================================

def apresentar_tela():

    largura_tela = tela.get_width()
    altura_tela = tela.get_height()

    escala = min(
        largura_tela / LARGURA,
        altura_tela / ALTURA
    )

    novo_tamanho = (
        int(LARGURA * escala),
        int(ALTURA * escala)
    )

    tela_escalada = pygame.transform.scale(
        tela_jogo,
        novo_tamanho
    )

    tela.fill(
        (
            0,
            0,
            0
        )
    )

    tela.blit(
        tela_escalada,
        (
            (largura_tela - novo_tamanho[0]) // 2,
            (altura_tela - novo_tamanho[1]) // 2
        )
    )


# ==========================================
# CLOCK
# ==========================================

clock = pygame.time.Clock()


# ==========================================
# TELA INICIAL
# ==========================================

if not tela_inicial(tela):

    pygame.quit()
    sys.exit()


# ==========================================
# CENAS
# ==========================================

if not mostrar_cenas(tela):

    pygame.quit()
    sys.exit()


# ==========================================
# CARREGAR CHÃO
# ==========================================

chao = carregar_chao()


# ==========================================
# CARREGAR PAREDE
# ==========================================

parede = carregar_parede()


# ==========================================
# CARREGAR SPRITES DO JOGADOR
# ==========================================

(
    baixo,
    cima,
    esquerda,
    direita
) = carregar_personagem()


# ==========================================
# CARREGAR SPRITES DO EREN
# ==========================================

sprites_eren = carregar_eren()


# ==========================================
# CARREGAR CORAÇÃO
# ==========================================

sprites_coracao = carregar_coracao()


# ==========================================
# CARREGAR SPRITES DO PBRR
# ==========================================

(
    pbrr_frente,
    pbrr_costas,
    pbrr_esquerda,
    pbrr_direita
) = carregar_pbrr()


# ==========================================
# CRIAR PBRR
# ==========================================

pbrr = PBRR(
    pbrr_frente,
    pbrr_costas,
    pbrr_esquerda,
    pbrr_direita,
    LARGURA // 2,
    ALTURA // 2
)


# ==========================================
# CRIAR JOGADOR
# ==========================================

jogador = Jogador(
    baixo,
    cima,
    esquerda,
    direita,
    largura_tela=LARGURA,
    altura_tela=ALTURA
)


# ==========================================
# CRIAR EREN
# ==========================================

eren = Eren(
    *sprites_eren,
    jogador
)


# ==========================================
# CRIAR CORAÇÃO
# ==========================================

coracao = Coracao(
    sprites_coracao,
    LARGURA,
    ALTURA
)


# ==========================================
# CRIAR INTERFACE
# ==========================================

interface = Interface(
    VIDA_MAXIMA
)


# ==========================================
# CRIAR CAIXA DE DIÁLOGO
# ==========================================

caixa_dialogo = CaixaDialogo(
    LARGURA,
    ALTURA
)


# ==========================================
# INICIAR PRIMEIRO DIÁLOGO
# ==========================================

caixa_dialogo.iniciar(
    0
)


# ==========================================
# LOOP PRINCIPAL
# ==========================================

rodando = True


while rodando:

    # ======================================
    # EVENTOS
    # ======================================

    for evento in pygame.event.get():

        # ----------------------------------
        # FECHAR JOGO
        # ----------------------------------

        if evento.type == pygame.QUIT:

            rodando = False


        # ----------------------------------
        # TECLAS
        # ----------------------------------

        if evento.type == pygame.KEYDOWN:

            # ==================================
            # F11
            # ==================================

            if evento.key == pygame.K_F11:

                alternar_fullscreen()


            # ==================================
            # ESPAÇO = CORAÇÃO
            # ==================================

            if (
                evento.key == pygame.K_SPACE
                and not caixa_dialogo.ativo
            ):

                coracao.ativo = not coracao.ativo


            # ==================================
            # DIÁLOGO
            # ==================================

            caixa_dialogo.processar_evento(
                evento
            )


    # ======================================
    # ATUALIZAR CAIXA DE DIÁLOGO
    # ======================================

    caixa_dialogo.atualizar()


    # ======================================
    # PODE MOVER?
    # ======================================

    if caixa_dialogo.pode_mover():

        # ==================================
        # ATUALIZAR PBRR
        # ==================================

        pbrr.atualizar(jogador, interface)


        # ==================================
        # ATUALIZAR JOGADOR
        # ==================================

        jogador.atualizar()


        # ==================================
        # ATUALIZAR EREN
        # ==================================

        eren.atualizar()


        # ==================================
        # ATUALIZAR CORAÇÃO
        # ==================================

        coracao.atualizar()


    interface.atualizar_particulas()


    # ======================================
    # LIMPAR TELA
    # ======================================

    tela_jogo.fill(
        (
            0,
            0,
            0
        )
    )


    # ======================================
    # DESENHAR MAPA
    # ======================================

    desenhar_mapa(
        tela_jogo,
        chao,
        parede
    )


    # ======================================
    # ORDEM DOS PERSONAGENS
    # ======================================

    pbrr.desenhar_ataques(
        tela_jogo
    )

    personagens = [
        (pbrr.obter_rect().bottom, pbrr.desenhar),
        (eren.y, eren.desenhar),
        (jogador.y, jogador.desenhar)
    ]
    personagens.sort(key=lambda personagem: personagem[0])

    for _, desenhar_personagem in personagens:
        desenhar_personagem(tela_jogo)


    # ======================================
    # DESENHAR CORAÇÃO
    # ======================================

    coracao.desenhar(
        tela_jogo,
        jogador
    )


    # ======================================
    # DESENHAR VIDA
    # ======================================

    interface.desenhar_vida(
        tela_jogo
    )

    interface.desenhar_particulas(
        tela_jogo
    )


    # ======================================
    # DESENHAR CAIXA DE DIÁLOGO
    # ======================================

    caixa_dialogo.desenhar(
        tela_jogo
    )


    # ======================================
    # APRESENTAR TELA
    # ======================================

    apresentar_tela()


    # ======================================
    # ATUALIZAR DISPLAY
    # ======================================

    pygame.display.flip()


    # ======================================
    # FPS
    # ======================================

    clock.tick(FPS)


# ==========================================
# ENCERRAR PYGAME
# ==========================================

pygame.quit()

sys.exit()