import pygame


# ==================================================
# CONFIGURAÇÃO DAS CENAS
# ==================================================

# COLOQUE AQUI TODAS AS CENAS, NA ORDEM
#
# Quer 3 cenas?
# Deixe 3 arquivos.
#
# Quer 10 cenas?
# Adicione mais 7 aqui.
#
# A ordem da lista é a ordem em que elas aparecem.

ARQUIVOS_CENAS = [
    "assets/cenas/cena1.jpg",
    "assets/cenas/cena2.jpg",
    "assets/cenas/cena3.jpg",
    "assets/cenas/cena4.jpg",
]


# ==================================================
# CONFIGURAÇÕES DA TRANSIÇÃO
# ==================================================

DURACAO_CENA = 3000
DURACAO_FADE = 800


# ==================================================
# CARREGAR CENAS
# ==================================================

def carregar_cenas(tamanho):

    cenas = []

    for arquivo in ARQUIVOS_CENAS:

        imagem = pygame.image.load(
            arquivo
        ).convert()

        imagem = pygame.transform.scale(
            imagem,
            tamanho
        )

        cenas.append(imagem)

    return cenas


# ==================================================
# MOSTRAR CENAS
# ==================================================

def mostrar_cenas(tela):

    clock = pygame.time.Clock()

    largura = tela.get_width()
    altura = tela.get_height()

    # ----------------------------------------------
    # CARREGAR
    # ----------------------------------------------

    cenas = carregar_cenas(
        (
            largura,
            altura
        )
    )

    # ----------------------------------------------
    # SE NÃO EXISTIR CENA
    # ----------------------------------------------

    if len(cenas) == 0:

        return True

    # ----------------------------------------------
    # CADA CENA
    # ----------------------------------------------

    for indice in range(len(cenas)):

        cena_atual = cenas[indice]

        # ==========================================
        # MOSTRAR CENA
        # ==========================================

        inicio = pygame.time.get_ticks()

        pulou = False

        while True:

            agora = pygame.time.get_ticks()

            tempo_passado = (
                agora - inicio
            )

            # --------------------------------------
            # EVENTOS
            # --------------------------------------

            for evento in pygame.event.get():

                if evento.type == pygame.QUIT:

                    return False

                if evento.type == pygame.KEYDOWN:

                    # Qualquer tecla pula
                    # para a próxima cena

                    if evento.key == pygame.K_ESCAPE:

                        return False

                    pulou = True

            # --------------------------------------
            # DESENHAR
            # --------------------------------------

            tela.blit(
                cena_atual,
                (
                    0,
                    0
                )
            )

            pygame.display.flip()

            # --------------------------------------
            # TERMINAR CENA
            # --------------------------------------

            if (
                tempo_passado >= DURACAO_CENA
                or
                pulou
            ):

                break

            clock.tick(60)

        # ==========================================
        # TRANSIÇÃO PARA PRÓXIMA CENA
        # ==========================================

        if indice < len(cenas) - 1:

            proxima_cena = cenas[
                indice + 1
            ]

            inicio_fade = (
                pygame.time.get_ticks()
            )

            while True:

                agora = pygame.time.get_ticks()

                tempo_fade = (
                    agora - inicio_fade
                )

                progresso = (
                    tempo_fade
                    /
                    DURACAO_FADE
                )

                if progresso > 1:

                    progresso = 1

                # ----------------------------------
                # CENA ATUAL
                # ----------------------------------

                tela.blit(
                    cena_atual,
                    (
                        0,
                        0
                    )
                )

                # ----------------------------------
                # PRÓXIMA CENA
                # ----------------------------------

                proxima_cena.set_alpha(
                    int(
                        progresso * 255
                    )
                )

                tela.blit(
                    proxima_cena,
                    (
                        0,
                        0
                    )
                )

                # ----------------------------------
                # ATUALIZAR
                # ----------------------------------

                pygame.display.flip()

                # ----------------------------------
                # TERMINOU
                # ----------------------------------

                if progresso >= 1:

                    proxima_cena.set_alpha(
                        255
                    )

                    break

                clock.tick(60)

    # ==================================================
    # TODAS AS CENAS TERMINARAM
    # ==================================================

    return True