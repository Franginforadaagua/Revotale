import pygame
import math


def tela_inicial(tela):

    clock = pygame.time.Clock()

    # ==================================================
    # LOGO
    # ==================================================

    logo_original = pygame.image.load(
        "assets/jogo/logo.png"
    ).convert_alpha()

    # Tamanho da logo
    logo_largura = 500

    proporcao = (
        logo_original.get_height()
        / logo_original.get_width()
    )

    logo_altura = int(
        logo_largura * proporcao
    )

    logo = pygame.transform.smoothscale(
        logo_original,
        (
            logo_largura,
            logo_altura
        )
    )

    # ==================================================
    # FONTE
    # ==================================================

    fonte = pygame.font.Font(
        None,
        32
    )

    # ==================================================
    # ANIMAÇÕES
    # ==================================================

    tempo = 0

    brilho = 0
    iniciando = False

    # ==================================================
    # LOOP DA TELA INICIAL
    # ==================================================

    while True:

        # ==============================================
        # EVENTOS
        # ==============================================

        for evento in pygame.event.get():

            if evento.type == pygame.QUIT:

                return False

            if evento.type == pygame.KEYDOWN:

                # ESC fecha o jogo
                if evento.key == pygame.K_ESCAPE:

                    return False

                # Qualquer outra tecla inicia
                iniciando = True

                brilho = 255

        # ==============================================
        # TEMPO
        # ==============================================

        tempo += 0.05

        # ==============================================
        # FUNDO
        # ==============================================

        tela.fill(
            (
                0,
                0,
                0
            )
        )

        # ==============================================
        # MOVIMENTO SUAVE DA LOGO
        # ==============================================

        movimento_y = math.sin(
            tempo
        ) * 5

        # ==============================================
        # POSIÇÃO DA LOGO
        # ==============================================

        logo_x = (
            tela.get_width()
            -
            logo.get_width()
        ) // 2

        logo_y = (
            tela.get_height()
            -
            logo.get_height()
        ) // 2 - 100

        logo_y += int(
            movimento_y
        )

        # ==============================================
        # DESENHAR LOGO
        # ==============================================

        tela.blit(
            logo,
            (
                logo_x,
                logo_y
            )
        )

        # ==============================================
        # TEXTO
        # ==============================================

        texto = fonte.render(
            "Aperte qualquer botão para começar",
            True,
            (
                255,
                255,
                255
            )
        )

        texto_rect = texto.get_rect(
            center=(
                tela.get_width() // 2,
                tela.get_height() // 2 + 180
            )
        )

        # ==============================================
        # TEXTO PISCANDO
        # ==============================================

        alpha_texto = int(
            150
            +
            math.sin(tempo * 2) * 80
        )

        texto.set_alpha(
            alpha_texto
        )

        tela.blit(
            texto,
            texto_rect
        )

        # ==============================================
        # BRILHO AO APERTAR TECLA
        # ==============================================

        if iniciando:

            # Reduz o brilho aos poucos
            brilho -= 15

            if brilho < 0:

                brilho = 0

            # Camada branca transparente
            camada_brilho = pygame.Surface(
                tela.get_size(),
                pygame.SRCALPHA
            )

            camada_brilho.fill(
                (
                    255,
                    255,
                    255,
                    brilho
                )
            )

            tela.blit(
                camada_brilho,
                (
                    0,
                    0
                )
            )

            # Quando o brilho terminar,
            # começa o jogo
            if brilho <= 0:

                return True

        # ==============================================
        # ATUALIZAR TELA
        # ==============================================

        pygame.display.flip()

        clock.tick(60)
