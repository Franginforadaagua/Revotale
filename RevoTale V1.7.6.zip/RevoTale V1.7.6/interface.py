import random

import pygame

from config import ESCALA_BARRA_VIDA


class Interface:

    def __init__(
        self,
        vida_maxima
    ):

        self.vida = vida_maxima

        self.vida_maxima = vida_maxima

        self.fonte_vida = pygame.font.Font(
            None,
            32
        )

        self.sprite_icone = pygame.image.load(
            "assets/BarraVida/Icone.png"
        ).convert_alpha()

        self.sprite_borda = pygame.image.load(
            "assets/BarraVida/borda.png"
        ).convert_alpha()

        self.sprite_meio = pygame.image.load(
            "assets/BarraVida/meio.png"
        ).convert_alpha()

        self.sprites_sangue = [
            pygame.image.load(
                "assets/particulas/sangue1.png"
            ).convert_alpha(),
            pygame.image.load(
                "assets/particulas/sangue2.png"
            ).convert_alpha()
        ]
        self.particulas = []
        self.morta = False

        self.som_morte = pygame.mixer.Sound(
            "sfx/morte.wav"
        )

        self.sprite_icone = self._preparar_sprite(
            self.sprite_icone
        )

        self.sprite_borda = self._preparar_sprite(
            self.sprite_borda
        )

        self.sprite_meio = self._preparar_sprite(
            self.sprite_meio
        )

        self.inicio_barra = 10 * ESCALA_BARRA_VIDA
        self.fim_barra = 44 * ESCALA_BARRA_VIDA
        self.espaco_icone = 2 * ESCALA_BARRA_VIDA
        self.largura_barra = (
            (self.vida_maxima - 1)
            * self.sprite_meio.get_width()
            +
            2
        )
        self.altura_barra = 4 * ESCALA_BARRA_VIDA
        self.limite_rotacao_particula = 18
        self.velocidade_rotacao_particula = 12

    def receber_dano(self, dano, origem=None):
        if dano <= 0 or self.morta:
            return

        self.vida = max(0, self.vida - dano)

        if self.vida == 0:
            self.morta = True
            self.som_morte.play()
            return

        quantidade = dano * 10
        x, y = self.obter_origem_particulas()

        for _ in range(quantidade):
            sprite = random.choice(self.sprites_sangue)
            self.particulas.append({
                "sprite": sprite,
                "x": x,
                "y": y,
                "velocidade_x": random.uniform(-1.5, 1.5),
                "velocidade_y": random.uniform(-5, -2),
                "angulo": random.uniform(-18, 18),
                "sentido_rotacao": random.choice((-1, 1)),
                "inicio": pygame.time.get_ticks(),
                "duracao": 500
            })

    def obter_origem_particulas(self):
        x = 20
        y = 20
        x_barra = x + self.sprite_icone.get_width()
        x_barra += self.espaco_icone
        x_barra -= 5
        x_sprites = x_barra - 10
        x_borda = (
            x_sprites
            + (self.vida_maxima - 1) * self.sprite_meio.get_width()
            + 2
        )
        y_meio = y + (
            self.sprite_icone.get_height()
            - self.sprite_meio.get_height()
        ) // 2
        return (
            x_borda + self.sprite_borda.get_width(),
            y_meio + self.sprite_meio.get_height() // 2
        )

    def atualizar_particulas(self):
        particulas_ativas = []
        agora = pygame.time.get_ticks()
        for particula in self.particulas:
            tempo_decorrido = agora - particula["inicio"]
            if tempo_decorrido >= particula["duracao"]:
                continue

            particula["alpha"] = int(
                255 * (1 - tempo_decorrido / particula["duracao"])
            )
            particula["velocidade_y"] += 0.25
            particula["x"] += particula["velocidade_x"]
            particula["y"] += particula["velocidade_y"]
            particula["angulo"] += (
                particula["sentido_rotacao"]
                *
                self.velocidade_rotacao_particula
            )

            if abs(particula["angulo"]) >= self.limite_rotacao_particula:
                particula["angulo"] = (
                    self.limite_rotacao_particula
                    *
                    (1 if particula["angulo"] > 0 else -1)
                )
                particula["sentido_rotacao"] *= -1

            if particula["y"] <= 640:
                particulas_ativas.append(particula)

        self.particulas = particulas_ativas

    def desenhar_particulas(self, tela):
        for particula in self.particulas:
            sprite_base = particula["sprite"].copy()
            sprite_base.set_alpha(particula["alpha"])
            sprite = pygame.transform.rotate(
                sprite_base,
                particula["angulo"]
            )
            centro = (
                particula["x"] + particula["sprite"].get_width() / 2,
                particula["y"] + particula["sprite"].get_height() / 2
            )
            tela.blit(
                sprite,
                sprite.get_rect(center=centro)
            )

    @staticmethod
    def _preparar_sprite(sprite):

        area = sprite.get_bounding_rect()
        sprite = sprite.subsurface(area).copy()

        return pygame.transform.scale(
            sprite,
            (
                sprite.get_width() * ESCALA_BARRA_VIDA,
                sprite.get_height() * ESCALA_BARRA_VIDA
            )
        )

    # ==========================================
    # DESENHAR VIDA
    # ==========================================

    @staticmethod
    def _desenhar_preenchimento_vida(
        tela,
        x,
        y,
        largura,
        altura,
        raio,
        cor
    ):

        pygame.draw.rect(
            tela,
            cor,
            (
                x,
                y,
                largura,
                altura
            ),
            border_radius=raio
        )

    def desenhar_vida(
        self,
        tela
    ):

        x = 20
        y = 20
        x_icone = x
        x_barra = x_icone + self.sprite_icone.get_width()
        x_barra += self.espaco_icone
        x_barra -= 5
        x_sprites = x_barra - 5
        x_sprites -= 5
        y_meio = y + (
            self.sprite_icone.get_height()
            -
            self.sprite_meio.get_height()
        ) // 2
        y_meio += 2
        y_barra = y_meio + 3
        y_borda = y + (
            self.sprite_icone.get_height()
            -
            self.sprite_borda.get_height()
        ) // 2
        y_borda += 2

        raio = self.altura_barra // 2
        x_borda = (
            x_sprites
            + (
                self.vida_maxima - 1
            ) * self.sprite_meio.get_width()
            + 2
        )
        largura_barra_desenhada = (
            x_borda
            -
            x_sprites
            +
            4
        )

        pygame.draw.rect(
            tela,
            (128, 128, 128),
            (
                x_sprites,
                y_barra,
                largura_barra_desenhada,
                self.altura_barra
            ),
            border_radius=raio
        )

        largura_vermelha = (
            self.vida
            * self.sprite_meio.get_width()
        )

        if self.vida == self.vida_maxima:
            largura_vermelha = largura_barra_desenhada

        if largura_vermelha > 0:

            percentual_vida = (
                self.vida
                /
                self.vida_maxima
            )
            intensidade_vermelha = int(
                210
                +
                20 * (1 - percentual_vida)
            )

            self._desenhar_preenchimento_vida(
                tela,
                x_sprites,
                y_barra,
                largura_vermelha,
                self.altura_barra,
                raio,
                (
                    intensidade_vermelha,
                    0,
                    0
                )
            )

        for indice in range(self.vida_maxima):

            largura_meio = self.sprite_meio.get_width()

            if indice == self.vida_maxima - 1:
                largura_meio = 2

            x_meio = (
                x_sprites
                + indice * self.sprite_meio.get_width()
            )

            tela.blit(
                self.sprite_meio,
                (
                    x_sprites
                    + indice * self.sprite_meio.get_width(),
                    y_meio
                ),
                pygame.Rect(
                    0,
                    0,
                    largura_meio,
                    self.sprite_meio.get_height()
                )
            )

        tela.blit(
            self.sprite_icone,
            (
                x_icone,
                y
            )
        )

        tela.blit(
            self.sprite_borda,
            (
                x_borda,
                y_borda
            )
        )

        texto = (
            f"HP: "
            f"{self.vida}/"
            f"{self.vida_maxima}"
        )

        imagem_texto = (
            self.fonte_vida.render(
                texto,
                True,
                (255, 255, 255)
            )
        )

        tela.blit(
            imagem_texto,
            (
                20,
                y + self.sprite_icone.get_height() + 8
            )
        )
