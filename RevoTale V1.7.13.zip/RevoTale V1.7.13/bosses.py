import os
import random

import pygame

from config import ALTURA, LARGURA
from colisao import eh_parede


# Adicione novos identificadores nesta lista quando novos bosses existirem.
BOSS_ORDEM = [
    "pbrr",
    "boss2",
    "boss3",
    "boss4"
]


# Dados individuais de cada boss.
# A ordem dos documentos é definida pela sequência de BOSS_ORDEM e pelo campo
# "documento" de cada boss. Para trocar o documento de um boss, basta alterar esse valor.
BOSS_DADOS = {
    "pbrr": {
        "nome": "PBRR",
        "vida": 20,
        "dano": 1,
        "documento": "assets/Documentos/documento1.jpeg"
    },
    "boss2": {
        "nome": "Boss 2",
        "vida": 25,
        "dano": 1,
        "documento": "assets/Documentos/documento2.jpeg"
    },
    "boss3": {
        "nome": "Boss 3",
        "vida": 30,
        "dano": 2,
        "documento": "assets/Documentos/documento3.jpeg"
    },
    "boss4": {
        "nome": "Boss 4",
        "vida": 40,
        "dano": 2,
        "documento": "assets/Documentos/documento4.jpeg"
    }
}


VELOCIDADE_BALA = 10
INTERVALO_DISPARO = 250


class GerenciadorBosses:

    def __init__(self, bosses, jogador):
        self.bosses = bosses
        self.jogador = jogador
        self.indice = -1
        self.boss = None
        self.identificador = None
        self.dados = None
        self.vida = 0
        self.vida_maxima = 0
        self.finalizado = False
        self.mensagem = ""
        self.mensagem_expira = 0
        self.balas = []
        self.tempo_ultimo_disparo = 0
        self.direcao_disparo = pygame.Vector2(0, 1)
        self.dialogo_pendente = None
        self.iniciado = False
        self.sprite_bala = pygame.image.load(
            "assets/ataques/ataque1.png"
        ).convert_alpha()
        self.sprite_papel = pygame.image.load(
            "assets/Documentos/Papel.png"
        ).convert_alpha()
        self.sprite_papel = pygame.transform.scale(
            self.sprite_papel,
            (
                max(1, int(self.sprite_papel.get_width() * 1.35)),
                max(1, int(self.sprite_papel.get_height() * 1.35))
            )
        )
        self.item_papel = None
        self.documento_em_exibicao = None
        self.documento_ativo = False
        self.efeito_derrota = None

    def iniciar(self):
        if self.iniciado:
            return

        self.iniciado = True
        self._proximo_boss()

    def _proximo_boss(self):
        self.indice += 1

        while self.indice < len(BOSS_ORDEM):
            identificador = BOSS_ORDEM[self.indice]
            boss = self.bosses.get(identificador)
            dados = BOSS_DADOS.get(identificador)

            if boss is not None and dados is not None:
                self.identificador = identificador
                self.boss = boss
                self.dados = dados
                self.boss.dano_ataque = dados["dano"]
                self.vida = dados["vida"]
                self.vida_maxima = self.vida
                if self.indice > 0:
                    self.dialogo_pendente = identificador
                self.mensagem = (
                    f"Boss {self.indice + 1}/{len(BOSS_ORDEM)}: "
                    f"{dados['nome']}"
                )
                self.mensagem_expira = pygame.time.get_ticks() + 2200
                return

            self.indice += 1

        self.boss = None
        self.identificador = None
        self.dados = None
        self.finalizado = True
        self.mensagem = "Todos os bosses foram derrotados!"
        self.mensagem_expira = pygame.time.get_ticks() + 5000

    def consumir_dialogo_pendente(self):
        identificador = self.dialogo_pendente
        self.dialogo_pendente = None
        return identificador

    def atualizar(self, interface):
        if not self.iniciado or self.boss is None:
            return

        if self.efeito_derrota is not None:
            self._atualizar_efeito_derrota()
            return

        if self.item_papel is not None or self.documento_ativo:
            return

        self.boss.atualizar(self.jogador, interface)
        self._atualizar_balas()

        teclas = pygame.key.get_pressed()
        if any(
            teclas[tecla]
            for tecla in (
                pygame.K_LEFT,
                pygame.K_RIGHT,
                pygame.K_UP,
                pygame.K_DOWN
            )
        ):
            self._disparar_se_pronto()

    def _obter_direcao_disparo(self):
        direcao = pygame.Vector2(
            self.jogador.direcao_mira
        )
        direcao.normalize_ip()
        return direcao

    def _disparar_se_pronto(self):
        agora = pygame.time.get_ticks()
        if agora - self.tempo_ultimo_disparo < INTERVALO_DISPARO:
            return

        self.direcao_disparo = self._obter_direcao_disparo()
        origem = self.jogador.obter_rect_dano().center
        self.balas.append({
            "posicao": pygame.Vector2(origem),
            "direcao": self.direcao_disparo.copy()
        })
        self.tempo_ultimo_disparo = agora

    def _iniciar_efeito_derrota(self):
        self.efeito_derrota = {
            "inicio": pygame.time.get_ticks(),
            "duracao": 1000,
            "offset_x": 0.0,
            "offset_y": 0.0
        }

    def _atualizar_efeito_derrota(self):
        agora = pygame.time.get_ticks()
        elapsed = agora - self.efeito_derrota["inicio"]
        duracao = self.efeito_derrota["duracao"]

        if elapsed >= duracao:
            self.efeito_derrota = None
            self._criar_item_papel()
            return

        progresso = elapsed / duracao
        tremor = 3.0 * progresso
        self.efeito_derrota["offset_x"] = random.uniform(-tremor, tremor)
        self.efeito_derrota["offset_y"] = random.uniform(
            -tremor * 0.5, tremor * 0.5)

    def _criar_item_papel(self):
        if self.boss is None:
            return

        if not self.dados or not self.dados.get("documento"):
            return

        rect = self.sprite_papel.get_rect(
            center=self.boss.obter_rect_alvo().center
        )
        rect.centery -= 12
        self.item_papel = {
            "rect": rect,
            "documento": self.dados["documento"],
            "sprite": self.sprite_papel,
            "vel_y": -6.5,
            "vel_x": random.uniform(-2.2, 2.2),
            "gravidade": 0.28,
            "angulo": random.choice([-5, 5]),
            "rotacao_vel": random.choice([-1.0, 1.0]),
            "quicada": True,
            "altura_quicada": 0.0,
            "tempo_quica": 0.0,
            "girando": True
        }

    def _iniciar_documento(self, documento):
        if not documento:
            return

        if not os.path.exists(documento):
            return

        imagem = pygame.image.load(documento).convert_alpha()
        self.documento_em_exibicao = {
            "imagem": imagem,
            "alpha": 0,
            "fase": "in",
            "inicio": pygame.time.get_ticks(),
            "scroll": 0,
            "documento": documento,
            "rect": imagem.get_rect(center=(self.jogador.x, self.jogador.y))
        }
        self.documento_ativo = True

    def atualizar_documentos(self, jogador):
        if self.item_papel is not None:
            self.item_papel["rect"].x += self.item_papel["vel_x"]
            self.item_papel["rect"].y += self.item_papel["vel_y"]
            self.item_papel["vel_y"] += self.item_papel["gravidade"]

            if self.item_papel["girando"]:
                self.item_papel["angulo"] += self.item_papel["rotacao_vel"]

            if self.item_papel["rect"].bottom >= self.boss.obter_rect_alvo().bottom + 16:
                self.item_papel["rect"].bottom = self.boss.obter_rect_alvo(
                ).bottom + 16
                if self.item_papel["quicada"]:
                    self.item_papel["vel_y"] = -1.0
                    self.item_papel["vel_x"] *= 1.2
                    self.item_papel["quicada"] = False
                    self.item_papel["tempo_quica"] = pygame.time.get_ticks()
                    self.item_papel["altura_quicada"] = 2.0
                else:
                    self.item_papel["vel_y"] = 0
                    self.item_papel["vel_x"] *= 0.92
                    self.item_papel["rotacao_vel"] = 0
                    self.item_papel["girando"] = False

                if abs(self.item_papel["vel_x"]) < 0.15:
                    self.item_papel["vel_x"] = 0

            if self.item_papel["rect"].left < 0:
                self.item_papel["rect"].left = 0
                self.item_papel["vel_x"] *= -0.4
            elif self.item_papel["rect"].right > LARGURA:
                self.item_papel["rect"].right = LARGURA
                self.item_papel["vel_x"] *= -0.4

            if jogador.obter_rect().colliderect(self.item_papel["rect"]):
                self._iniciar_documento(self.item_papel["documento"])
                self.item_papel = None

        if self.documento_em_exibicao is None:
            return

        agora = pygame.time.get_ticks()
        estado = self.documento_em_exibicao

        if estado["fase"] == "in":
            elapsed = agora - estado["inicio"]
            estado["alpha"] = min(255, int((elapsed / 500) * 255))
            if elapsed >= 500:
                estado["alpha"] = 255
                estado["fase"] = "visivel"
                estado["inicio"] = agora

        elif estado["fase"] == "visivel":
            teclas = pygame.key.get_pressed()
            if teclas[pygame.K_UP]:
                estado["scroll"] -= 10
            if teclas[pygame.K_DOWN]:
                estado["scroll"] += 10

            rel_x, rel_y = pygame.mouse.get_rel()
            if rel_y != 0:
                estado["scroll"] += rel_y * 0.8

            if pygame.key.get_pressed()[pygame.K_SPACE] or pygame.key.get_pressed()[pygame.K_RETURN]:
                estado["fase"] = "out"
                estado["inicio"] = agora

            imagem = estado["imagem"]
            altura_total = imagem.get_height()
            max_scroll = max(0, altura_total - ALTURA)
            estado["scroll"] = max(-max_scroll, min(0, estado["scroll"]))

        elif estado["fase"] == "out":
            elapsed = agora - estado["inicio"]
            estado["alpha"] = max(0, 255 - int((elapsed / 500) * 255))
            if elapsed >= 500:
                self.documento_em_exibicao = None
                self.documento_ativo = False
                self._proximo_boss()

    def desenhar_documentos(self, tela):
        if self.item_papel is not None:
            sprite = self.item_papel["sprite"]
            sprite_rot = pygame.transform.rotate(
                sprite, self.item_papel["angulo"])
            rect = sprite_rot.get_rect(center=self.item_papel["rect"].center)
            tela.blit(sprite_rot, rect)

        if self.documento_em_exibicao is None:
            return

        estado = self.documento_em_exibicao
        imagem = estado["imagem"].copy()
        imagem.set_alpha(estado["alpha"])

        rect = imagem.get_rect(center=(LARGURA // 2, ALTURA // 2))
        rect.top += int(estado["scroll"])
        tela.blit(imagem, rect)

    def _atualizar_balas(self):
        novas_balas = []
        boss_rect = self.boss.obter_rect_alvo()

        for bala in self.balas:
            bala["posicao"] += bala["direcao"] * VELOCIDADE_BALA
            bala_rect = self.sprite_bala.get_rect(
                center=bala["posicao"]
            )

            if bala_rect.colliderect(boss_rect):
                self.vida = max(0, self.vida - 1)
                self.mensagem = f"{self.dados['nome']}: {self.vida} HP"
                self.mensagem_expira = pygame.time.get_ticks() + 900
                if self.vida == 0:
                    self.boss.ataques.clear()
                    self._iniciar_efeito_derrota()
                    self.balas = []
                    return
                continue

            pontos = [
                (bala_rect.left, bala_rect.top),
                (bala_rect.right - 1, bala_rect.top),
                (bala_rect.left, bala_rect.bottom - 1),
                (bala_rect.right - 1, bala_rect.bottom - 1)
            ]
            if any(eh_parede(x, y) for x, y in pontos):
                continue

            if (
                bala_rect.right >= 0
                and bala_rect.left <= LARGURA
                and bala_rect.bottom >= 0
                and bala_rect.top <= ALTURA
            ):
                novas_balas.append(bala)

        self.balas = novas_balas

    def desenhar_balas(self, tela):
        for bala in self.balas:
            tela.blit(
                self.sprite_bala,
                self.sprite_bala.get_rect(center=bala["posicao"])
            )

    def obter_boss(self):
        return self.boss

    def desenhar_interface(self, tela):
        if self.boss is None or self.dados is None:
            return

        largura = 360
        altura = 16
        x = (LARGURA - largura) // 2
        y = 18
        proporcao = self.vida / self.vida_maxima

        pygame.draw.rect(tela, (25, 25, 25), (x, y, largura, altura))
        pygame.draw.rect(
            tela,
            (190, 35, 45),
            (x, y, int(largura * proporcao), altura)
        )
        pygame.draw.rect(tela, (240, 220, 190), (x, y, largura, altura), 2)

        fonte = pygame.font.Font(None, 26)
        nome = fonte.render(self.dados["nome"], True, (255, 255, 255))
        tela.blit(nome, (x, y + altura + 4))

        if pygame.time.get_ticks() < self.mensagem_expira:
            mensagem = fonte.render(self.mensagem, True, (255, 230, 160))
            tela.blit(
                mensagem,
                mensagem.get_rect(center=(LARGURA // 2, ALTURA - 34))
            )
