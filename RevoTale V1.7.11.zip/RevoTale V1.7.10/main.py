import pygame
import sys


# ==========================================
# CONFIGURAÇÕES
# ==========================================

from config import (
    LARGURA,
    ALTURA,
    FPS,
    TITULO,
    VIDA_MAXIMA
)


# ==========================================
# TELA INICIAL
# ==========================================

from tela_inicial import tela_inicial


# ==========================================
# CENAS
# ==========================================

from cenas import mostrar_cenas


# ==========================================
# RECURSOS
# ==========================================

from recursos import (
    carregar_chao,
    carregar_parede,
    carregar_personagem,
    carregar_coracao,
    carregar_eren,
    carregar_pbrr,
    carregar_boss
)


# ==========================================
# JOGADOR
# ==========================================

from jogador import Jogador


# ==========================================
# EREN
# ==========================================

from eren import Eren


# ==========================================
# CORAÇÃO
# ==========================================

from coracao import Coracao


# ==========================================
# PBRR
# ==========================================

from PBRR import PBRR


# ==========================================
# BOSSES
# ==========================================

from bosses import GerenciadorBosses


# ==========================================
# INTERFACE
# ==========================================

from interface import Interface


# ==========================================
# MAPA
# ==========================================

from mapa import (
    desenhar_chao,
    desenhar_paredes
)


# ==========================================
# CAIXA DE DIÁLOGO
# ==========================================

from caixa_dialogo import CaixaDialogo


# ==========================================
# SOMBRAS
# ==========================================

from sombra import SistemaSombras


# ==========================================
# INICIAR PYGAME
# ==========================================

pygame.init()


# ==========================================
# JANELA
# ==========================================

tela = pygame.display.set_mode(
    (
        0,
        0
    ),
    pygame.FULLSCREEN
)

fullscreen = True


# ==========================================
# TELA INTERNA DO JOGO
# ==========================================

tela_jogo = pygame.Surface(
    (
        LARGURA,
        ALTURA
    )
)


# ==========================================
# TÍTULO
# ==========================================

pygame.display.set_caption(
    TITULO
)


# ==========================================
# FUNÇÃO FULLSCREEN
# ==========================================

def alternar_fullscreen():

    global tela
    global fullscreen

    fullscreen = not fullscreen

    if fullscreen:

        tela = pygame.display.set_mode(
            (
                0,
                0
            ),
            pygame.FULLSCREEN
        )

    else:

        tela = pygame.display.set_mode(
            (
                LARGURA,
                ALTURA
            ),
            pygame.RESIZABLE
        )


# ==========================================
# APRESENTAR TELA
# ==========================================

def apresentar_tela():

    largura_tela = tela.get_width()
    altura_tela = tela.get_height()

    escala = min(
        largura_tela / LARGURA,
        altura_tela / ALTURA
    )

    novo_tamanho = (
        int(LARGURA * escala),
        int(ALTURA * escala)
    )

    tela_escalada = pygame.transform.scale(
        tela_jogo,
        novo_tamanho
    )

    tela.fill(
        (
            0,
            0,
            0
        )
    )

    tela.blit(
        tela_escalada,
        (
            (largura_tela - novo_tamanho[0]) // 2,
            (altura_tela - novo_tamanho[1]) // 2
        )
    )


# ==========================================
# CLOCK
# ==========================================

clock = pygame.time.Clock()


# ==========================================
# TELA INICIAL
# ==========================================

if not tela_inicial(tela):

    pygame.quit()
    sys.exit()


# ==========================================
# CENAS
# ==========================================

if not mostrar_cenas(tela):

    pygame.quit()
    sys.exit()


# ==========================================
# CARREGAR CHÃO
# ==========================================

chao = carregar_chao()


# ==========================================
# CARREGAR PAREDE
# ==========================================

parede = carregar_parede()


# ==========================================
# CARREGAR SPRITES DO JOGADOR
# ==========================================

(
    baixo,
    cima,
    esquerda,
    direita
) = carregar_personagem()


# ==========================================
# CARREGAR SPRITES DO EREN
# ==========================================

sprites_eren = carregar_eren()


# ==========================================
# CARREGAR CORAÇÃO
# ==========================================

sprites_coracao = carregar_coracao()


# ==========================================
# CARREGAR SPRITES DO PBRR
# ==========================================

(
    pbrr_frente,
    pbrr_costas,
    pbrr_esquerda,
    pbrr_direita
) = carregar_pbrr()


# ==========================================
# CRIAR PBRR
# ==========================================

pbrr = PBRR(
    pbrr_frente,
    pbrr_costas,
    pbrr_esquerda,
    pbrr_direita,
    LARGURA // 2,
    ALTURA // 2
)


# ==========================================
# CRIAR OUTROS BOSSES
# ==========================================

bosses = {
    "pbrr": pbrr
}

for identificador, pasta in (
    ("boss2", "boss2"),
    ("boss3", "boss3"),
    ("boss4", "boss4")
):
    bosses[identificador] = PBRR(
        *carregar_boss(pasta),
        LARGURA // 2,
        ALTURA // 2
    )


# ==========================================
# CRIAR JOGADOR
# ==========================================

jogador = Jogador(
    baixo,
    cima,
    esquerda,
    direita,
    largura_tela=LARGURA,
    altura_tela=ALTURA
)


# ==========================================
# GERENCIADOR DE BOSSES
# ==========================================

gerenciador_bosses = GerenciadorBosses(
    bosses,
    jogador
)


# ==========================================
# CRIAR EREN
# ==========================================

eren = Eren(
    *sprites_eren,
    jogador
)


# ==========================================
# CRIAR CORAÇÃO
# ==========================================

coracao = Coracao(
    sprites_coracao,
    LARGURA,
    ALTURA
)

jogador.definir_coracao(coracao)


# ==========================================
# CRIAR INTERFACE
# ==========================================

interface = Interface(
    VIDA_MAXIMA
)


# ==========================================
# CRIAR CAIXA DE DIÁLOGO
# ==========================================

caixa_dialogo = CaixaDialogo(
    LARGURA,
    ALTURA
)


# ==========================================
# SISTEMA DE SOMBRAS
# ==========================================

sistema_sombras = SistemaSombras(
    posicao_luz=(120, -180),
    cor=(10, 13, 24),
    intensidade=0.62
)


# ==========================================
# INICIAR PRIMEIRO DIÁLOGO
# ==========================================

caixa_dialogo.iniciar(
    0
)


# ==========================================
# LOOP PRINCIPAL
# ==========================================

rodando = True


while rodando:

    # ======================================
    # EVENTOS
    # ======================================

    for evento in pygame.event.get():

        # ----------------------------------
        # FECHAR JOGO
        # ----------------------------------

        if evento.type == pygame.QUIT:

            rodando = False

        # ----------------------------------
        # TECLAS
        # ----------------------------------

        if evento.type == pygame.KEYDOWN:

            # ==================================
            # F11
            # ==================================

            if evento.key == pygame.K_F11:

                alternar_fullscreen()

            # ==================================
            # DIÁLOGO
            # ==================================

            caixa_dialogo.processar_evento(
                evento
            )

    # ======================================
    # ATUALIZAR CAIXA DE DIÁLOGO
    # ======================================

    caixa_dialogo.atualizar()

    # ======================================
    # ATUALIZAR JOGO
    # ======================================

    if not interface.morta and caixa_dialogo.pode_mover():

        # ==================================
        # ATUALIZAR PBRR
        # ==================================

        gerenciador_bosses.atualizar(interface)

        identificador_dialogo = (
            gerenciador_bosses.consumir_dialogo_pendente()
        )
        if identificador_dialogo is not None:
            caixa_dialogo.iniciar_boss(identificador_dialogo)

        # ==================================
        # ATUALIZAR JOGADOR
        # ==================================

        jogador.atualizar()

        coracao.ativo = jogador.usando_coracao

        # ==================================
        # ATUALIZAR EREN
        # ==================================

        eren.atualizar()

        # ==================================
        # ATUALIZAR CORAÇÃO
        # ==================================

        coracao.atualizar()

    interface.atualizar_particulas()

    # ======================================
    # LIMPAR TELA
    # ======================================

    tela_jogo.fill(
        (
            0,
            0,
            0
        )
    )

    if interface.morta:
        interface.desenhar_gore(
            tela_jogo
        )
        jogador.desenhar(
            tela_jogo,
            interface.obter_alpha_game_over()
        )
    else:
        # ======================================
        # DESENHAR MAPA
        # ======================================

        desenhar_chao(
            tela_jogo,
            chao
        )

        boss = gerenciador_bosses.obter_boss()
        personagens = [
            (eren.obter_rect().bottom, eren),
            (jogador.obter_rect().bottom, jogador)
        ]
        if boss is not None:
            personagens.append((boss.obter_rect().bottom, boss))
        personagens.sort(key=lambda personagem: personagem[0])

        sistema_sombras.desenhar(
            tela_jogo,
            [personagem for _, personagem in personagens]
        )

        desenhar_paredes(
            tela_jogo,
            parede
        )

        interface.desenhar_gore(
            tela_jogo
        )

        if boss is not None:
            boss.desenhar_ataques(tela_jogo)

        gerenciador_bosses.desenhar_balas(
            tela_jogo
        )

        for _, personagem in personagens:
            personagem.desenhar(tela_jogo)

        # ======================================
        # DESENHAR CORAÇÃO
        # ======================================

        coracao.desenhar(
            tela_jogo,
            jogador
        )

        # ======================================
        # DESENHAR VIDA
        # ======================================

        interface.desenhar_vida(
            tela_jogo
        )

        interface.stamina = jogador.stamina
        interface.desenhar_stamina(
            tela_jogo
        )

        gerenciador_bosses.desenhar_interface(
            tela_jogo
        )

    if not interface.morta:
        # ======================================
        # DESENHAR CAIXA DE DIÁLOGO
        # ======================================

        caixa_dialogo.desenhar(
            tela_jogo
        )

    # ======================================
    # APRESENTAR TELA
    # ======================================

    apresentar_tela()

    # ======================================
    # ATUALIZAR DISPLAY
    # ======================================

    pygame.display.flip()

    # ======================================
    # FPS
    # ======================================

    clock.tick(FPS)


# ==========================================
# ENCERRAR PYGAME
# ==========================================

pygame.quit()

sys.exit()
