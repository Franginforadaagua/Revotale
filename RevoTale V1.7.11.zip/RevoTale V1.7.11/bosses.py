import pygame

from config import ALTURA, LARGURA
from colisao import eh_parede


# Adicione novos identificadores nesta lista quando novos bosses existirem.
BOSS_ORDEM = [
    "pbrr",
    "boss2",
    "boss3",
    "boss4"
]


# Dados individuais de cada boss.
BOSS_DADOS = {
    "pbrr": {
        "nome": "PBRR",
        "vida": 20,
        "dano": 1
    },
    "boss2": {
        "nome": "Boss 2",
        "vida": 25,
        "dano": 1
    },
    "boss3": {
        "nome": "Boss 3",
        "vida": 30,
        "dano": 2
    },
    "boss4": {
        "nome": "Boss 4",
        "vida": 40,
        "dano": 2
    }
}


VELOCIDADE_BALA = 10
INTERVALO_DISPARO = 250


class GerenciadorBosses:

    def __init__(self, bosses, jogador):
        self.bosses = bosses
        self.jogador = jogador
        self.indice = -1
        self.boss = None
        self.identificador = None
        self.dados = None
        self.vida = 0
        self.vida_maxima = 0
        self.finalizado = False
        self.mensagem = ""
        self.mensagem_expira = 0
        self.balas = []
        self.tempo_ultimo_disparo = 0
        self.direcao_disparo = pygame.Vector2(0, 1)
        self.dialogo_pendente = None
        self.sprite_bala = pygame.image.load(
            "assets/ataques/ataque1.png"
        ).convert_alpha()
        self._proximo_boss()

    def _proximo_boss(self):
        self.indice += 1

        while self.indice < len(BOSS_ORDEM):
            identificador = BOSS_ORDEM[self.indice]
            boss = self.bosses.get(identificador)
            dados = BOSS_DADOS.get(identificador)

            if boss is not None and dados is not None:
                self.identificador = identificador
                self.boss = boss
                self.dados = dados
                self.boss.dano_ataque = dados["dano"]
                self.vida = dados["vida"]
                self.vida_maxima = self.vida
                if self.indice > 0:
                    self.dialogo_pendente = identificador
                self.mensagem = (
                    f"Boss {self.indice + 1}/{len(BOSS_ORDEM)}: "
                    f"{dados['nome']}"
                )
                self.mensagem_expira = pygame.time.get_ticks() + 2200
                return

            self.indice += 1

        self.boss = None
        self.identificador = None
        self.dados = None
        self.finalizado = True
        self.mensagem = "Todos os bosses foram derrotados!"
        self.mensagem_expira = pygame.time.get_ticks() + 5000

    def consumir_dialogo_pendente(self):
        identificador = self.dialogo_pendente
        self.dialogo_pendente = None
        return identificador

    def atualizar(self, interface):
        if self.boss is None:
            return

        self.boss.atualizar(self.jogador, interface)
        self._atualizar_balas()

        teclas = pygame.key.get_pressed()
        if any(
            teclas[tecla]
            for tecla in (
                pygame.K_LEFT,
                pygame.K_RIGHT,
                pygame.K_UP,
                pygame.K_DOWN
            )
        ):
            self._disparar_se_pronto()

    def _obter_direcao_disparo(self):
        direcao = pygame.Vector2(
            self.jogador.direcao_mira
        )
        direcao.normalize_ip()
        return direcao

    def _disparar_se_pronto(self):
        agora = pygame.time.get_ticks()
        if agora - self.tempo_ultimo_disparo < INTERVALO_DISPARO:
            return

        self.direcao_disparo = self._obter_direcao_disparo()
        origem = self.jogador.obter_rect_dano().center
        self.balas.append({
            "posicao": pygame.Vector2(origem),
            "direcao": self.direcao_disparo.copy()
        })
        self.tempo_ultimo_disparo = agora

    def _atualizar_balas(self):
        novas_balas = []
        boss_rect = self.boss.obter_rect_alvo()

        for bala in self.balas:
            bala["posicao"] += bala["direcao"] * VELOCIDADE_BALA
            bala_rect = self.sprite_bala.get_rect(
                center=bala["posicao"]
            )

            if bala_rect.colliderect(boss_rect):
                self.vida = max(0, self.vida - 1)
                self.mensagem = f"{self.dados['nome']}: {self.vida} HP"
                self.mensagem_expira = pygame.time.get_ticks() + 900
                if self.vida == 0:
                    self.boss.ataques.clear()
                    self._proximo_boss()
                    self.balas = []
                    return
                continue

            pontos = [
                (bala_rect.left, bala_rect.top),
                (bala_rect.right - 1, bala_rect.top),
                (bala_rect.left, bala_rect.bottom - 1),
                (bala_rect.right - 1, bala_rect.bottom - 1)
            ]
            if any(eh_parede(x, y) for x, y in pontos):
                continue

            if (
                bala_rect.right >= 0
                and bala_rect.left <= LARGURA
                and bala_rect.bottom >= 0
                and bala_rect.top <= ALTURA
            ):
                novas_balas.append(bala)

        self.balas = novas_balas

    def desenhar_balas(self, tela):
        for bala in self.balas:
            tela.blit(
                self.sprite_bala,
                self.sprite_bala.get_rect(center=bala["posicao"])
            )

    def obter_boss(self):
        return self.boss

    def desenhar_interface(self, tela):
        if self.boss is None or self.dados is None:
            return

        largura = 360
        altura = 16
        x = (LARGURA - largura) // 2
        y = 18
        proporcao = self.vida / self.vida_maxima

        pygame.draw.rect(tela, (25, 25, 25), (x, y, largura, altura))
        pygame.draw.rect(
            tela,
            (190, 35, 45),
            (x, y, int(largura * proporcao), altura)
        )
        pygame.draw.rect(tela, (240, 220, 190), (x, y, largura, altura), 2)

        fonte = pygame.font.Font(None, 26)
        nome = fonte.render(self.dados["nome"], True, (255, 255, 255))
        tela.blit(nome, (x, y + altura + 4))

        if pygame.time.get_ticks() < self.mensagem_expira:
            mensagem = fonte.render(self.mensagem, True, (255, 230, 160))
            tela.blit(
                mensagem,
                mensagem.get_rect(center=(LARGURA // 2, ALTURA - 34))
            )